//This class sets the variables of the you objects
package celestialmatch;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
//import java.lang.Object;
import celestialmatch.Signs.*;

//import celestialmatch.CelestialMatch.*;
/* NOTES:
    - Java has a class that adjusts for time zones:
        o ZonedDateTime (https://stackoverflow.com/questions/999172/how-to-parse-a-date)

*/

public class You {
    //variables
    private Sign sun, moon, ascendant, mars, venus, descendant, uranus, pluto;
    private String firstName, lastName, birthDay, birthTime;
    
    /* 2 constructors
        1. You (Date, String): constructor that will eventually be the only constructor;
            - the user enters their birth date and time
        2. You (Sign, String): tests the ascendant function; simply a test constructor */
    You (String fName, String lName, String gDate, String bTime) throws ParseException {
        setFirstName (fName);           setLastName (lName);
        setBirthDay (gDate);            setBirthTime (bTime);
        setSun (gDate);                 setPluto (gDate);
        setVenus (gDate);               setMoon(gDate);
        setMars (gDate);                setAsc(getSun(), bTime);
        setUranus (gDate);              setDesc();
    }

    private void setFirstName (String fName) { firstName = fName; }
    private void setLastName (String lName) { lastName = lName; }
    private void setBirthDay (String bDay) { birthDay = bDay; }
    private void setBirthTime (String bTime) { birthTime = bTime; }
    
    //setter methods:
    /* setSign (WORKS)
        - allows the user to enter a string and return a Sign
        - is a safety net function
            o created in case I needed to parse a sign*/
    private Sign setSign (String s) {
        if (s.equals("ARIES") || s.equals("Aries"))
            return Sign.ARIES;
        else if (s.equals("TAURUS") || s.equals ("Taurus"))
            return Sign.TAURUS;
        else if (s.equals("GEMINI") || s.equals ("Gemini"))
            return Sign.GEMINI;
        else if (s.equals("CANCER") || s.equals ("Cancer"))
            return Sign.CANCER;
        else if (s.equals("LEO") || s.equals ("Leo"))
            return Sign.LEO;
        else if (s.equals("VIRGO") || s.equals ("Virgo"))
            return Sign.VIRGO;
        else if (s.equals("LIBRA") || s.equals ("Libra"))
            return Sign.LIBRA;
        else if (s.equals("SCORPIO") || s.equals ("Scorpio"))
            return Sign.SCORPIO;
        else if (s.equals("SAGITTARIUS") || s.equals ("Sagittarius"))
            return Sign.SAGITTARIUS;
        else if (s.equals("CAPRICORN") || s.equals ("Capricorn"))
            return Sign.CAPRICORN;
        else if (s.equals("AQUARIUS") || s.equals ("Aquarius"))
            return Sign.AQUARIUS;
        else
            return Sign.PISCES;
    }//end setSign
    
    //Sun (WORKS)
    private void setSun (String gDate) throws ParseException {
    /* DATES FOR THE SUN SIGNS:
        Aries   | March 21 - Apr 19                 Taurus  | Apr 20 - May 20
        Gemini  | May 21 - June 20                  Cancer  | June 21 - July 22
        Leo     | July 23 - Aug 22                  Virgo   | Aug 23 - Sept 22
        Libra   | Sept 23 - Oct 22                  Scorpio | Oct 23 - Nov 21
        Sag     | Nov 22 - Dec 21                   Cap     | Dec 22 - Jan 19
        Aquarius| Jan 20 - Feb 18                   Pisces  | Feb 19 - Mar 20 */
    
                Date uDate;
        SimpleDateFormat sdf = new SimpleDateFormat ("MM/dd");
        uDate = sdf.parse(gDate);

        //create date objects
            //create aries date objects
            Date ariesBegin = sdf.parse("03/20");
            Date ariesEnd = sdf.parse("04/20");
            //create taurus date objects
            Date taurusBegin = sdf.parse ("04/19");
            Date taurusEnd = sdf.parse ("05/21");
            //create gemini date objects
            Date geminiBegin = sdf.parse ("05/20");
            Date geminiEnd = sdf.parse ("06/21");
            //create cancer date objects
            Date cancerBegin = sdf.parse ("06/20");
            Date cancerEnd = sdf.parse ("07/23");
            //create leo date objects
            Date leoBegin = sdf.parse ("07/22");
            Date leoEnd = sdf.parse ("08/23");
            //create virgo date objects
            Date virgoBegin = sdf.parse ("08/22");
            Date virgoEnd = sdf.parse ("09/23");
            //create libra date objects
            Date libraBegin = sdf.parse ("09/22");
            Date libraEnd = sdf.parse ("10/23");
            //create scorpio date objects
            Date scorpioBegin = sdf.parse ("10/22");
            Date scorpioEnd = sdf.parse ("11/23");
            //create sag date objects
            Date sagBegin = sdf.parse ("11/20");
            Date sagEnd = sdf.parse ("12/22");
            //create cap date objects
            Date capBegin = sdf.parse ("12/21");
            Date capEnd = sdf.parse ("01/20");
            //create aqua date objects
            Date aquaBegin = sdf.parse ("01/19");
            Date aquaEnd = sdf.parse ("02/19");
            //create pisces date objects
            Date piscesBegin = sdf.parse ("02/18");
            Date piscesEnd = sdf.parse ("03/21");
            
            
        if (uDate.after(ariesBegin) && uDate.before(ariesEnd)) {sun = Sign.ARIES;}              //if an aries
        else if (uDate.after(taurusBegin) && uDate.before(taurusEnd)) {sun = Sign.TAURUS;}      //if a taurus
        else if (uDate.after(geminiBegin) && uDate.before(geminiEnd)) {sun = Sign.GEMINI;}      //if a gemini
        else if (uDate.after(cancerBegin) && uDate.before(cancerEnd)) {sun = Sign.CANCER;}      //if a cancer
        else if (uDate.after(leoBegin) && uDate.before(leoEnd)) {sun = Sign.LEO;}               //if a leo
        else if (uDate.after(virgoBegin) && uDate.before(virgoEnd)) {sun = Sign.VIRGO;}         //if a virgo
        else if (uDate.after(libraBegin) && uDate.before(libraEnd)) {sun = Sign.LIBRA;}         //if a libra
        else if (uDate.after(scorpioBegin) && uDate.before(scorpioEnd)) {sun = Sign.SCORPIO;}   //if a scorpio
        else if (uDate.after(sagBegin) && uDate.before(sagEnd)) {sun = Sign.SAGITTARIUS;}       //if a sagittarius
        else if (uDate.after(aquaBegin) && uDate.before(aquaEnd)) {sun = Sign.AQUARIUS;}        //if an aquarius
        else if (uDate.after(piscesBegin) && uDate.before(piscesEnd)) {sun = Sign.PISCES;}      //if a pisces
        else { sun = Sign.CAPRICORN; } //if (uDate.after(capBegin) && uDate.before(capEnd)) {sun = Sign.CAPRICORN;}
    }//end setSun
    
    /* Moon (WORKS)
        - list of moon dates & time found at http://witcheslore.com/moon-sign-chart/
        - to loop through a circular array of the signs
            o calculates the number of days since 01/01/1900
            o gets the index of the sign w/ (# of loop)%13 */
    private void setMoon (String uDate) throws ParseException {
        String signArr [] = {"Aquarius", "Pisces", "Aries", "Taurus", "Gemini",
                                  "Cancer", "Leo", "Virgo", "Libra", "Scorpio",
                                  "Sagittarius", "Capricorn", "Aquarius"};
        
        long calcDays = givenTwoDates (uDate);
        int loopThrough = ((int)calcDays % 13);
        String moonSign;

        try
            { moonSign = signArr[loopThrough]; }
        catch (ArrayIndexOutOfBoundsException e){
           //System.out.println ("Original Moon Index: " + loopThrough);
           if (loopThrough == -1) { loopThrough = 0; }
           moonSign = signArr[loopThrough]; 
        }

        moon = setSign (moonSign);
    }//end setMoon
    
    /* Ascendant (WORKS)
        - list of ascendant times found at http://horoscopes.hypermart.net/rising-sign-table.shtml */
    private void setAsc (Sign a, String birthTime) throws ParseException {

        /* FOR THE ARIES SUN SIGN:
            00:00:00 - 02:00:00 (Aquarius)      02:00:00 - 4:00:00 (Pisces)         04:00:00 - 06:00:00 (Aries)
            06:00:00 - 8:00:00 (Taurus)         08:00:00 - 10:00:00 (Gemini)        10:00:00 - 12:00:00 (Cancer)
            12:00:00 - 14:00:00 (Leo)           14:00:00 - 16:00:00 (Virgo)         16:00:00 - 18:00:00 (Libra)
            18:00:00 - 20:00:00 (Scorpio)       20:00:00 - 22:00:00 (Sag)           22:00:00 - 00:00:00 (Capricorn) */
        if (a == Sign.ARIES) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else  {ascendant = Sign.CAPRICORN;}//(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
        
        /* FOR THE TAURUS SUN SIGN
            00:00:00 - 02:00:00 (Pisces)        02:00:00 - 04:00:00 (Aries)       04:00:00 - 06:00:00 (Taurus)
            06:00:00 - 8:00:00 (Gemini)         08:00:00 - 10:00:00 (Cancer)      10:00:00 - 12:00:00 (Leo)
            12:00:00 - 14:00:00 (Virgo)         14:00:00 - 16:00:00 (Libra)       16:00:00 - 18:00:00 (Scorpio)
            18:00:00 - 20:00:00 (Sagittarius)   20:00:00 - 22:00:00 (Capricorn)   22:00:00 - 00:00:00 (Aquarius) */
        else if (a == Sign.TAURUS) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else {ascendant = Sign.AQUARIUS;} //(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
        
        /* FOR THE GEMINI SUN SIGN
            00:00:00 - 02:00:00 (Aries)        02:00:00 - 04:00:00 (Taurus)       04:00:00 - 06:00:00 (Gemini)
            06:00:00 - 08:00:00 (Cancer)       08:00:00 - 10:00:00 (Leo)          10:00:00 - 12:00:00 (Virgo)
            12:00:00 - 14:00:00 (Libra)        14:00:00 - 16:00:00 (Scorpio)      16:00:00 - 18:00:00 (Sagittarius)
            18:00:00 - 20:00:00 (Capricorn)    20:00:00 - 22:00:00 (Aquarius)     22:00:00 - 00:00:00 (Pisces)        */
        else if (a == Sign.GEMINI) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else {ascendant = Sign.PISCES;} //(isTimeBetweenTwoTime ("22:00:00", "22:00:00", birthTime) )
        }
        
        /* FOR THE CANCER SUN SIGN
            00:00:00 - 02:00:00 (Taurus)          02:00:00 - 04:00:00 (Gemini)     04:00:00 - 06:00:00 (Cancer)
            06:00:00 - 08:00:00 (Leo)             08:00:00 - 10:00:00 (Virgo)      10:00:00 - 12:00:00 (Libra)
            12:00:00 - 14:00:00 (Scorpio)         14:00:00 - 16:00:00 (Sag)        16:00:00 - 18:00:00 (Capricorn)
            18:00:00 - 20:00:00 (Aquarius)        20:00:00 - 22:00:00 (Pisces)     22:00:00 - 00:00:00 (Aries)                 */
        else if (a == Sign.CANCER) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.PISCES;}
            else    {ascendant = Sign.ARIES;} //(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
        
        /* FOR THE LEO SUN SIGN
            00:00:00 - 02:00:00 (Gemini)           02:00:00 - 04:00:00  (Cancer)     04:00:00 - 06:00:00 (Leo)
            06:00:00 - 08:00:00 (Virgo)            08:00:00 - 10:00:00 (Libra)       10:00:00 - 12:00:00 (Scorpio)
            12:00:00 - 14:00:00 (Sagittarius)      14:00:00 - 16:00:00 (Capricorn)   16:00:00 - 18:00:00 (Aquarius)
            18:00:00 - 20:00:00 (Pisces)           20:00:00 - 22:00:00 (Aries)       22:00:00 - 00:00:00 (Taurus)           */
        else if (a == Sign.LEO) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.ARIES;}
            else    {ascendant = Sign.TAURUS;} //(isTimeBetweenTwoTime ("22:32:00", "00:31:59", birthTime) ) {ascendant = Sign.TAURUS;}
        }
        
        /* FOR THE VIRGO SUN SIGN
            00:00:00 - 02:00:00 (Cancer)           02:00:00 - 04:00:00 (Leo)         04:00:00 - 06:00:00 (Virgo)
            06:00:00 - 08:00:00 (Libra)            08:00:00 - 10:00:00 (Scorpio)     10:00:00 - 12:00:00 (Sagittarius)
            12:00:00 - 14:00:00 (Capricorn)        14:00:00 - 16:00:00 (Aquarius)    16:00:00 - 18:00:00 (Pisces)
            18:00:00 - 20:00:00 (Aries)            20:00:00 - 22:00:00 (Taurus)      22:00:00 - 00:00:00 (Gemini)           */
        else if (a == Sign.VIRGO) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else {ascendant = Sign.GEMINI;}//(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
        
        /* FOR THE LIBRA SUN SIGN
            00:00:00 - 02:00:00 (Leo)              02:00:00 - 04:00:00 (Virgo)       04:00:00 - 06:00:00 (Libra)
            06:00:00 - 08:00:00 (Scorpio)          08:00:00 - 10:00:00 (Sag)         10:00:00 - 12:00:00 (Capricorn)
            12:00:00 - 14:00:00 (Aquarius)         14:00:00 - 16:00:00 (Pisces)      16:00:00 - 18:00:00 (Aries)
            18:00:00 - 20:00:00 (Taurus)           20:00:00 - 22:00:00 (Gemini)      22:00:00 - 00:00:00 (Cancer)          */
        else if (a == Sign.LIBRA) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else    {ascendant = Sign.CANCER;}//(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )            
        }
        
        /* FOR THE SCROPIO SUN SIGN
            00:00:00 - 02:00:00 (Virgo)            02:00:00 - 04:00:00 (Libra)       04:00:00 - 06:00:00 (Scorpio)
            06:00:00 - 08:00:00 (Sagittarius)      08:00:00 - 10:00:00 (Capricorn)   10:00:00 - 12:00:00 (Aquarius)
            12:00:00 - 14:00:00 (Pisces)           14:00:00 - 16:00:00 (Aries)       16:00:00 - 18:00:00 (Taurus)
            18:00:00 - 20:00:00 (Gemini)           20:00:00 - 22:00:00 (Cancer)      22:00:00 - 00:00:00 (Leo)          */
        else if (a == Sign.SCORPIO) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.CANCER;}
            else    {ascendant = Sign.LEO;}//(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
        
        /* FOR THE SAGITTARIUS SUN SIGN
            00:00:00 - 02:00:00 (Libra)            02:00:00 - 04:00:00 (Scorpio)     04:00:00 - 06:00:00 (Sagittarius)
            06:00:00 - 08:00:00 (Capricorn)        08:00:00 - 10:00:00 (Aquarius)    10:00:00 - 12:00:00 (Pisces)
            12:00:00 - 14:00:00 (Aries)            14:00:00 - 16:00:00 (Taurus)      16:00:00 - 18:00:00 (Gemini)
            18:00:00 - 20:00:00 (Cancer)           20:00:00 - 22:00:00 (Leo)         22:00:00 - 00:00:00 (Virgo)            */
        else if (a == Sign.SAGITTARIUS) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.LEO;}
            else    {ascendant = Sign.VIRGO;}//(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
        
        /* FOR THE CAPRICORN SUN SIGN
            00:00:00 - 02:00:00 (Scorpio)          02:00:00 - 04:00:00 (Sag)         04:00:00 - 06:00:00 (Capricorn)
            06:00:00 - 08:00:00 (Aquarius)         08:00:00 - 10:00:00 (Pisces)      10:00:00 - 12:00:00 (Aries)
            12:00:00 - 14:00:00 (Taurus)           14:00:00 - 16:00:00 (Gemini)      16:00:00 - 18:00:00 (Cancer)
            18:00:00 - 20:00:00 (Leo)              20:00:00 - 22:00:00 (Virgo)       22:00:00 - 00:00:00 (Libra)            */
        else if (a == Sign.CAPRICORN) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else {ascendant = Sign.LIBRA;} //(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
        
        /* FOR THE AQUARIUS SUN SIGN
            00:00:00 - 02:00:00 (Sagittarius)      02:00:00 - 04:00:00 (Capricorn)    04:00:00 - 06:00:00 (Aquarius
            06:00:00 - 08:00:00 (Pisces)           08:00:00 - 10:00:00 (Aries)        10:00:00 - 12:00:00 (Taurus)
            12:00:00 - 14:00:00 (Gemini)           14:00:00 - 16:00:00 (Cancer)       16:00:00 - 18:00:00 (Leo)
            18:00:00 - 20:00:00 (Virgo)            20:00:00 - 22:00:00 (Libra)        22:00:00 - 00:00:00 (Scorpio)         */
        else if (a == Sign.AQUARIUS) {
            if (isTimeBetweenTwoTime ("00:32", "02:31", birthTime) ) {ascendant = Sign.SAGITTARIUS;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else {ascendant = Sign.SCORPIO;}//(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )            
        }
        
        /* FOR THE PISCES SUN SIGN
            00:00:00 - 02:00:00 (Capricorn)        02:00:00 - 04:00:00 (Aquarius)     04:00:00 - 06:00:00 (Pisces)
            06:00:00 - 08:00:00 (Aries)            08:00:00 - 10:00:00 (Taurus)       10:00:00 - 12:00:00 (Gemini)
            12:00:00 - 14:00:00 (Cancer)           14:00:00 - 16:00:00 (Leo)          16:00:00 - 18:00:00 (Virgo)
            18:00:00 - 20:00:00 (Libra )           20:00:00 - 22:00:00 (Scorpio)      22:00:00 - 00:00:00 (Sagittarius)
        */
        else { //pisces
            if (isTimeBetweenTwoTime ("00:32:00", "02:31", birthTime) ) {ascendant = Sign.CAPRICORN;}
            else if (isTimeBetweenTwoTime ("02:32", "04:31", birthTime) ) {ascendant = Sign.AQUARIUS;}
            else if (isTimeBetweenTwoTime ("04:32", "06:31", birthTime) ) {ascendant = Sign.PISCES;}
            else if (isTimeBetweenTwoTime ("06:32", "08:31", birthTime) ) {ascendant = Sign.ARIES;}
            else if (isTimeBetweenTwoTime ("08:32", "10:31", birthTime) ) {ascendant = Sign.TAURUS;}
            else if (isTimeBetweenTwoTime ("10:32", "12:31", birthTime) ) {ascendant = Sign.GEMINI;}
            else if (isTimeBetweenTwoTime ("12:32", "14:31", birthTime) ) {ascendant = Sign.CANCER;}
            else if (isTimeBetweenTwoTime ("14:32", "16:31", birthTime) ) {ascendant = Sign.LEO;}
            else if (isTimeBetweenTwoTime ("16:32", "18:31", birthTime) ) {ascendant = Sign.VIRGO;}
            else if (isTimeBetweenTwoTime ("18:32", "20:31", birthTime) ) {ascendant = Sign.LIBRA;}
            else if (isTimeBetweenTwoTime ("20:32", "22:31", birthTime) ) {ascendant = Sign.SCORPIO;}
            else {ascendant = Sign.SAGITTARIUS;} //(isTimeBetweenTwoTime ("22:00:00", "00:00:00", birthTime) )
        }
    }//end setAsc
    
    /* Mars (WORKS)
        - list of mars days found at https://cafeastrology.com/marssignstables.html
        - dates are limited from 1985 - 2000 */
    private void setMars (String gDate) throws ParseException {
        Date uDate;
        SimpleDateFormat sdf = new SimpleDateFormat ("MM/dd/yyyy");
        uDate = sdf.parse(gDate);        
        
         //Dec 25, 1984 1:38 AM Mars enters Pisces
        Date marsBegin1 = sdf.parse ("12/24/1984");
        Date marsEnd1 = sdf.parse ("02/02/1985");
        if (uDate.after (marsBegin1) && uDate.before (marsEnd1)) {mars = Sign.PISCES; }
        
        //Feb 2, 1985 12:19 PM Mars enters Aries
        Date marsBegin2 = sdf.parse ("02/01/1985");
        Date marsEnd2 = sdf.parse ("03/15/1985");
        if (uDate.after (marsBegin2) && uDate.before (marsEnd2)) {mars = Sign.ARIES; }        
        
        //Mar 15, 1985 12:06 AM Mars enters Taurus
        Date marsBegin3 = sdf.parse ("03/14/1985");
        Date marsEnd3 = sdf.parse ("04/26/1985");
        if (uDate.after (marsBegin3) && uDate.before (marsEnd3)) {mars = Sign.TAURUS; } 
        
        //Apr 26, 1985 4:13 AM Mars enters Gemini
        Date marsBegin4 = sdf.parse ("04/25/1985");
        Date marsEnd4 = sdf.parse ("06/09/1985");
        if (uDate.after (marsBegin4) && uDate.before (marsEnd4)) {mars = Sign.GEMINI; } 
        
        //June 9, 1985 5:40 AM Mars enters Cancer
        Date marsBegin5 = sdf.parse ("06/08/1985");
        Date marsEnd5 = sdf.parse ("07/24/1985");
        if (uDate.after (marsBegin5) && uDate.before (marsEnd5)) {mars = Sign.CANCER; }
        
        //July 24, 1985 11:04 PM Mars enters Leo
        Date marsBegin6 = sdf.parse ("07/23/1985");
        Date marsEnd6 = sdf.parse ("09/09/1985");
        if (uDate.after (marsBegin6) && uDate.before (marsEnd6)) {mars = Sign.LEO; }
        
        //Sep 9, 1985 8:31 PM Mars enters Virgo
        Date marsBegin7 = sdf.parse ("09/08/1985");
        Date marsEnd7 = sdf.parse ("10/27/1985");
        if (uDate.after (marsBegin7) && uDate.before (marsEnd7)) {mars = Sign.VIRGO; }
        
        //Oct 27, 1985 10:16 AM Mars enters Libra
        Date marsBegin8 = sdf.parse ("10/26/1985");
        Date marsEnd8 = sdf.parse ("12/14/1985");
        if (uDate.after (marsBegin8) && uDate.before (marsEnd8)) {mars = Sign.LIBRA; }
        
        //Dec 14, 1985 1:59 PM Mars enters Scorpio
        Date marsBegin9 = sdf.parse ("12/13/1985");
        Date marsEnd9 = sdf.parse ("02/02/1986");
        if (uDate.after (marsBegin9) && uDate.before (marsEnd9)) {mars = Sign.SCORPIO; }
        
        //Feb 2, 1986 1:27 AM Mars enters Sagittarius
        Date marsBegin10 = sdf.parse ("02/01/1986");
        Date marsEnd10 = sdf.parse ("03/27/1986");
        if (uDate.after (marsBegin10) && uDate.before (marsEnd10)) {mars = Sign.SAGITTARIUS; }
        
        //Mar 27, 1986 10:47 PM Mars enters Capricorn
        Date marsBegin11 = sdf.parse ("03/26/1986");
        Date marsEnd11 = sdf.parse ("10/08/1986");
        if (uDate.after (marsBegin11) && uDate.before (marsEnd11)) {mars = Sign.CAPRICORN; }
        
        //Oct 8, 1986 8:01 PM Mars enters Aquarius
        Date marsBegin12 = sdf.parse ("10/07/1986");
        Date marsEnd12 = sdf.parse ("11/25/1986");
        if (uDate.after (marsBegin12) && uDate.before (marsEnd12)) {mars = Sign.AQUARIUS; }
        
        //Nov 25, 1986 9:35 PM Mars enters Pisces
        Date marsBegin13 = sdf.parse ("11/24/1986");
        Date marsEnd13 = sdf.parse ("01/08/1987");
        if (uDate.after (marsBegin13) && uDate.before (marsEnd13)) {mars = Sign.PISCES; }
        
        //Jan 8, 1987 7:20 AM Mars enters Aries
        Date marsBegin14 = sdf.parse ("01/07/1987");
        Date marsEnd14 = sdf.parse ("02/20/1987");
        if (uDate.after (marsBegin14) && uDate.before (marsEnd14)) {mars = Sign.ARIES; }
        
        //Feb 20, 1987 9:44 AM Mars enters Taurus
        Date marsBegin15 = sdf.parse ("02/19/1987");
        Date marsEnd15 = sdf.parse ("04/05/1987");
        if (uDate.after (marsBegin15) && uDate.before (marsEnd15)) {mars = Sign.TAURUS; }
        
        //Apr 5, 1987 11:37 AM Mars enters Gemini
        Date marsBegin16 = sdf.parse ("04/04/1987");
        Date marsEnd16 = sdf.parse ("05/20/1987");
        if (uDate.after (marsBegin16) && uDate.before (marsEnd16)) {mars = Sign.GEMINI; }
        
        //May 20, 1987 10:01 PM Mars enters Cancer
        Date marsBegin17 = sdf.parse ("05/19/1987");
        Date marsEnd17 = sdf.parse ("07/06/1987");
        if (uDate.after (marsBegin17) && uDate.before (marsEnd17)) {mars = Sign.CANCER; }
        
        //July 6, 1987 11:46 AM Mars enters Leo
        Date marsBegin18 = sdf.parse ("07/05/1987");
        Date marsEnd18 = sdf.parse ("08/22/1987");
        if (uDate.after (marsBegin18) && uDate.before (marsEnd18)) {mars = Sign.LEO; }
        
        //Aug 22, 1987 2:51 PM Mars enters Virgo
        Date marsBegin19 = sdf.parse ("08/21/1987");
        Date marsEnd19 = sdf.parse ("10/08/1987");
        if (uDate.after (marsBegin19) && uDate.before (marsEnd19)) {mars = Sign.VIRGO; }
        
        //Oct 8, 1987 2:27 PM Mars enters Libra
        Date marsBegin20 = sdf.parse ("10/07/1987");
        Date marsEnd20 = sdf.parse ("11/23/1987");
        if (uDate.after (marsBegin20) && uDate.before (marsEnd20)) {mars = Sign.LIBRA; }
        
        //Nov 23, 1987 10:19 PM Mars enters Scorpio
        Date marsBegin21 = sdf.parse ("11/22/1987");
        Date marsEnd21 = sdf.parse ("01/08/1988");
        if (uDate.after (marsBegin21) && uDate.before (marsEnd21)) {mars = Sign.SCORPIO; }
        
        //Jan 8, 1988 10:24 AM Mars enters Sagittarius
        Date marsBegin22 = sdf.parse ("01/07/1988");
        Date marsEnd22 = sdf.parse ("02/22/1988");
        if (uDate.after (marsBegin22) && uDate.before (marsEnd22)) {mars = Sign.SAGITTARIUS; }
        
        //Feb 22, 1988 5:15 AM Mars enters Capricorn
        Date marsBegin23 = sdf.parse ("02/21/1988");
        Date marsEnd23 = sdf.parse ("04/06/1988");
        if (uDate.after (marsBegin23) && uDate.before (marsEnd23)) {mars = Sign.CAPRICORN; }
        
        //Apr 6, 1988 4:44 PM Mars enters Aquarius
        Date marsBegin24 = sdf.parse ("04/05/1988");
        Date marsEnd24 = sdf.parse ("05/22/1988");
        if (uDate.after (marsBegin24) && uDate.before (marsEnd24)) {mars = Sign.AQUARIUS; }        
        
        //May 22, 1988 2:42 AM Mars enters Pisces
        Date marsBegin25 = sdf.parse ("05/21/1988");
        Date marsEnd25 = sdf.parse ("07/13/1988");
        if (uDate.after (marsBegin25) && uDate.before (marsEnd25)) {mars = Sign.PISCES; }
        
        //July 13, 1988 3:00 PM Mars enters Aries
        Date marsBegin26 = sdf.parse ("07/12/1988");
        Date marsEnd26 = sdf.parse ("10/23/1988");
        if (uDate.after (marsBegin26) && uDate.before (marsEnd26)) {mars = Sign.ARIES; }
        
        //Oct 23, 1988 5:01 PM Mars Rx enters Pisces
        Date marsBegin27 = sdf.parse ("10/22/1988");
        Date marsEnd27 = sdf.parse ("11/01/1988");
        if (uDate.after (marsBegin27) && uDate.before (marsEnd27)) {mars = Sign.PISCES; }
        
        //Nov 1, 1988 7:57 AM Mars enters Aries
        Date marsBegin28 = sdf.parse ("10/31/1988");
        Date marsEnd28 = sdf.parse ("01/19/1989");
        if (uDate.after (marsBegin28) && uDate.before (marsEnd28)) {mars = Sign.ARIES; }
        
        //Jan 19, 1989 3:11 AM Mars enters Taurus
        Date marsBegin29 = sdf.parse ("01/18/1989");
        Date marsEnd29 = sdf.parse ("03/11/1989");
        if (uDate.after (marsBegin29) && uDate.before (marsEnd29)) {mars = Sign.TAURUS; }
        
        //Mar 11, 1989 3:51 AM Mars enters Gemini
        Date marsBegin30 = sdf.parse ("03/10/1989");
        Date marsEnd30 = sdf.parse ("04/28/1989");
        if (uDate.after (marsBegin30) && uDate.before (marsEnd30)) {mars = Sign.GEMINI; }
        
        //Apr 28, 1989 11:37 PM Mars enters Cancer
        Date marsBegin31 = sdf.parse ("04/27/1989");
        Date marsEnd31 = sdf.parse ("06/16/1989");
        if (uDate.after (marsBegin31) && uDate.before (marsEnd31)) {mars = Sign.CANCER; }
        
        //June 16, 1989 9:10 AM Mars enters Leo
        Date marsBegin32 = sdf.parse ("06/15/1989");
        Date marsEnd32 = sdf.parse ("08/03/1989");
        if (uDate.after (marsBegin32) && uDate.before (marsEnd32)) {mars = Sign.LEO; }
        
        //Aug 3, 1989 8:35 AM Mars enters Virgo
        Date marsBegin33 = sdf.parse ("08/02/1989");
        Date marsEnd33 = sdf.parse ("09/19/1989");
        if (uDate.after (marsBegin33) && uDate.before (marsEnd33)) {mars = Sign.VIRGO; }
        
        //Sep 19, 1989 9:38 AM Mars enters Libra
        Date marsBegin34 = sdf.parse ("09/18/1989");
        Date marsEnd34 = sdf.parse ("11/04/1989");
        if (uDate.after (marsBegin34) && uDate.before (marsEnd34)) {mars = Sign.LIBRA; }
        
        //Nov 4, 1989 12:29 AM Mars enters Scorpio
        Date marsBegin35 = sdf.parse ("11/03/1989");
        Date marsEnd35 = sdf.parse ("12/17/1989");
        if (uDate.after (marsBegin35) && uDate.before (marsEnd35)) {mars = Sign.SCORPIO; }
        
        //Dec 17, 1989 11:57 PM Mars enters Sagittarius
        Date marsBegin36 = sdf.parse ("12/16/1989");
        Date marsEnd36 = sdf.parse ("01/29/1990");
        if (uDate.after (marsBegin36) && uDate.before (marsEnd36)) {mars = Sign.SAGITTARIUS; }
        
        //Jan 29, 1990 9:10 AM Mars enters Capricorn
        Date marsBegin37 = sdf.parse ("01/28/1990");
        Date marsEnd37 = sdf.parse ("03/11/1990");
        if (uDate.after (marsBegin37) && uDate.before (marsEnd37)) {mars = Sign.CAPRICORN; }
        
        //Mar 11, 1990 10:54 AM Mars enters Aquarius
        Date marsBegin38 = sdf.parse ("03/10/1990");
        Date marsEnd38 = sdf.parse ("04/20/1990");
        if (uDate.after (marsBegin38) && uDate.before (marsEnd38)) {mars = Sign.AQUARIUS; }
        
        //Apr 20, 1990 5:09 PM Mars enters Pisces
        Date marsBegin39 = sdf.parse ("04/19/1990");
        Date marsEnd39 = sdf.parse ("05/31/1990");
        if (uDate.after (marsBegin39) && uDate.before (marsEnd39)) {mars = Sign.PISCES; }
        
        //May 31, 1990 2:11 AM Mars enters Aries
        Date marsBegin40 = sdf.parse ("05/30/1990");
        Date marsEnd40 = sdf.parse ("07/12/1990");
        if (uDate.after (marsBegin40) && uDate.before (marsEnd40)) {mars = Sign.ARIES; }
        
        //July 12, 1990 9:44 AM Mars enters Taurus
        Date marsBegin41 = sdf.parse ("07/11/1990");
        Date marsEnd41 = sdf.parse ("08/31/1990");
        if (uDate.after (marsBegin41) && uDate.before (marsEnd41)) {mars = Sign.TAURUS; }
        
        //Aug 31, 1990 6:40 AM Mars enters Gemini
        Date marsBegin42 = sdf.parse ("08/30/1990");
        Date marsEnd42 = sdf.parse ("12/14/1990");
        if (uDate.after (marsBegin42) && uDate.before (marsEnd42)) {mars = Sign.GEMINI; }
        
        //Dec 14, 1990 2:46 AM Mars Rx enters Taurus
        Date marsBegin43 = sdf.parse ("12/13/1990");
        Date marsEnd43 = sdf.parse ("01/20/1991");
        if (uDate.after (marsBegin43) && uDate.before (marsEnd43)) {mars = Sign.TAURUS; }
        
        //Jan 20, 1991 8:15 PM Mars enters Gemini
        Date marsBegin44 = sdf.parse ("01/19/1991");
        Date marsEnd44 = sdf.parse ("04/02/1991");
        if (uDate.after (marsBegin44) && uDate.before (marsEnd44)) {mars = Sign.GEMINI; }
        
        //Apr 2, 1991 7:49 PM Mars enters Cancer
        Date marsBegin45 = sdf.parse ("04/01/1991");
        Date marsEnd45 = sdf.parse ("05/26/1991");
        if (uDate.after (marsBegin45) && uDate.before (marsEnd45)) {mars = Sign.CANCER; }
        
        //May 26, 1991 7:19 AM Mars enters Leo
        Date marsBegin46 = sdf.parse ("05/25/1991");
        Date marsEnd46 = sdf.parse ("07/15/1991");
        if (uDate.after (marsBegin46) && uDate.before (marsEnd46)) {mars = Sign.LEO; }
        
        //July 15, 1991 7:36 AM Mars enters Virgo
        Date marsBegin47 = sdf.parse ("07/14/1991");
        Date marsEnd47 = sdf.parse ("09/01/1991");
        if (uDate.after (marsBegin47) && uDate.before (marsEnd47)) {mars = Sign.VIRGO; }
        
        //Sep 1, 1991 1:38 AM Mars enters Libra
        Date marsBegin48 = sdf.parse ("08/31/1991");
        Date marsEnd48 = sdf.parse ("10/16/1991");
        if (uDate.after (marsBegin48) && uDate.before (marsEnd48)) {mars = Sign.LIBRA; }
        
        //Oct 16, 1991 2:05 PM Mars enters Scorpio
        Date marsBegin49 = sdf.parse ("10/15/1991");
        Date marsEnd49 = sdf.parse ("11/28/1991");
        if (uDate.after (marsBegin49) && uDate.before (marsEnd49)) {mars = Sign.SCORPIO; }
        
        //Nov 28, 1991 9:19 PM Mars enters Sagittarius
        Date marsBegin50 = sdf.parse ("11/27/1991");
        Date marsEnd50 = sdf.parse ("01/09/1992");
        if (uDate.after (marsBegin50) && uDate.before (marsEnd50)) {mars = Sign.SAGITTARIUS; }
        
        //Jan 9, 1992 4:47 AM Mars enters Capricorn
        Date marsBegin51 = sdf.parse ("01/08/1992");
        Date marsEnd51 = sdf.parse ("02/17/1992");
        if (uDate.after (marsBegin51) && uDate.before (marsEnd51)) {mars = Sign.CAPRICORN; }
        
        //Feb 17, 1992 11:38 PM Mars enters Aquarius
        Date marsBegin52 = sdf.parse ("02/16/1992");
        Date marsEnd52 = sdf.parse ("03/27/1992");
        if (uDate.after (marsBegin52) && uDate.before (marsEnd52)) {mars = Sign.AQUARIUS; }
        
        //Mar 27, 1992 9:04 PM Mars enters Pisces
        Date marsBegin53 = sdf.parse ("03/26/1992");
        Date marsEnd53 = sdf.parse ("05/05/1992");
        if (uDate.after (marsBegin53) && uDate.before (marsEnd53)) {mars = Sign.PISCES; }
        
        //May 5, 1992 4:36 PM Mars enters Aries
        Date marsBegin54 = sdf.parse ("05/04/1992");
        Date marsEnd54 = sdf.parse ("06/14/1992");
        if (uDate.after (marsBegin54) && uDate.before (marsEnd54)) {mars = Sign.ARIES; }
        
        //June 14, 1992 10:56 AM Mars enters Taurus
        Date marsBegin55 = sdf.parse ("06/13/1992");
        Date marsEnd55 = sdf.parse ("07/26/1992");
        if (uDate.after (marsBegin55) && uDate.before (marsEnd55)) {mars = Sign.TAURUS; }
        
        //July 26, 1992 1:59 PM Mars enters Gemini
        Date marsBegin56 = sdf.parse ("07/25/1992");
        Date marsEnd56 = sdf.parse ("09/12/1992");
        if (uDate.after (marsBegin56) && uDate.before (marsEnd56)) {mars = Sign.GEMINI; }
        
        //Sep 12, 1992 1:05 AM Mars enters Cancer
        Date marsBegin57 = sdf.parse ("09/11/1992");
        Date marsEnd57 = sdf.parse ("04/27/1993");
        if (uDate.after (marsBegin57) && uDate.before (marsEnd57)) {mars = Sign.CANCER; }
        
        //Apr 27, 1993 6:40 PM Mars enters Leo
        Date marsBegin58 = sdf.parse ("04/26/1993");
        Date marsEnd58 = sdf.parse ("06/23/1993");
        if (uDate.after (marsBegin58) && uDate.before (marsEnd58)) {mars = Sign.LEO; }
        
        //June 23, 1993 2:42 AM Mars enters Virgo
        Date marsBegin59 = sdf.parse ("06/22/1993");
        Date marsEnd59 = sdf.parse ("08/11/1993");
        if (uDate.after (marsBegin59) && uDate.before (marsEnd59)) {mars = Sign.VIRGO; }
        
        //Aug 11, 1993 8:10 PM Mars enters Libra
        Date marsBegin60 = sdf.parse ("08/10/1993");
        Date marsEnd60 = sdf.parse ("09/26/1993");
        if (uDate.after (marsBegin60) && uDate.before (marsEnd60)) {mars = Sign.LIBRA; }
        
        //Sep 26, 1993 9:15 PM Mars enters Scorpio
        Date marsBegin61 = sdf.parse ("09/25/1993");
        Date marsEnd61 = sdf.parse ("11/09/1993");
        if (uDate.after (marsBegin61) && uDate.before (marsEnd61)) {mars = Sign.SCORPIO; }
        
        //Nov 9, 1993 12:29 AM Mars enters Sagittarius
        Date marsBegin62 = sdf.parse ("11/08/1993");
        Date marsEnd62 = sdf.parse ("12/19/1993");
        if (uDate.after (marsBegin62) && uDate.before (marsEnd62)) {mars = Sign.SAGITTARIUS; }
        
        //Dec 19, 1993 7:34 PM Mars enters Capricorn
        Date marsBegin63 = sdf.parse ("12/18/1993");
        Date marsEnd63 = sdf.parse ("01/27/1994");
        if (uDate.after (marsBegin63) && uDate.before (marsEnd63)) {mars = Sign.CAPRICORN; }
        
        //Jan 27, 1994 11:05 PM Mars enters Aquarius
        Date marsBegin64 = sdf.parse ("01/26/1994");
        Date marsEnd64 = sdf.parse ("03/07/1994");
        if (uDate.after (marsBegin64) && uDate.before (marsEnd64)) {mars = Sign.AQUARIUS; }
        
        //Mar 7, 1994 6:01 AM Mars enters Pisces
        Date marsBegin65 = sdf.parse ("03/06/1994");
        Date marsEnd65 = sdf.parse ("04/14/1994");
        if (uDate.after (marsBegin65) && uDate.before (marsEnd65)) {mars = Sign.PISCES; }
        
        //Apr 14, 1994 1:02 PM Mars enters Aries
        Date marsBegin66 = sdf.parse ("04/13/1994");
        Date marsEnd66 = sdf.parse ("05/23/1994");
        if (uDate.after (marsBegin66) && uDate.before (marsEnd66)) {mars = Sign.ARIES; }
        
        //May 23, 1994 5:37 PM Mars enters Taurus
        Date marsBegin67 = sdf.parse ("05/22/1994");
        Date marsEnd67 = sdf.parse ("07/03/1994");
        if (uDate.after (marsBegin67) && uDate.before (marsEnd67)) {mars = Sign.TAURUS; }
        
        //July 3, 1994 5:30 PM Mars enters Gemini
        Date marsBegin68 = sdf.parse ("07/02/1994");
        Date marsEnd68 = sdf.parse ("08/16/1994");
        if (uDate.after (marsBegin68) && uDate.before (marsEnd68)) {mars = Sign.GEMINI; }
        
        //Aug 16, 1994 2:15 PM Mars enters Cancer
        Date marsBegin69 = sdf.parse ("08/15/1994");
        Date marsEnd69 = sdf.parse ("10/04/1994");
        if (uDate.after (marsBegin69) && uDate.before (marsEnd69)) {mars = Sign.CANCER; }
        
        //Oct 4, 1994 10:48 AM Mars enters Leo
        Date marsBegin70 = sdf.parse ("10/03/1994");
        Date marsEnd70 = sdf.parse ("12/12/1994");
        if (uDate.after (marsBegin70) && uDate.before (marsEnd70)) {mars = Sign.LEO; }
        
        //Dec 12, 1994 6:32 AM Mars enters Virgo
        Date marsBegin71 = sdf.parse ("12/11/1994");
        Date marsEnd71 = sdf.parse ("01/22/1995");
        if (uDate.after (marsBegin71) && uDate.before (marsEnd71)) {mars = Sign.VIRGO; }
        
        //Jan 22, 1995 6:48 PM Mars Rx enters Leo
        Date marsBegin72 = sdf.parse ("01/21/1995");
        Date marsEnd72 = sdf.parse ("05/25/1995");
        if (uDate.after (marsBegin72) && uDate.before (marsEnd72)) {mars = Sign.LEO; }
        
        //May 25, 1995 11:09 AM Mars enters Virgo
        Date marsBegin73 = sdf.parse ("05/24/1995");
        Date marsEnd73 = sdf.parse ("07/21/1995");
        if (uDate.after (marsBegin73) && uDate.before (marsEnd73)) {mars = Sign.VIRGO; }
        
        //July 21, 1995 4:21 AM Mars enters Libra
        Date marsBegin74 = sdf.parse ("07/20/1995");
        Date marsEnd74 = sdf.parse ("09/07/1995");
        if (uDate.after (marsBegin74) && uDate.before (marsEnd74)) {mars = Sign.LIBRA; }
        
        //Sep 7, 1995 2:00 AM Mars enters Scorpio
        Date marsBegin75 = sdf.parse ("09/06/1995");
        Date marsEnd75 = sdf.parse ("10/20/1995");
        if (uDate.after (marsBegin75) && uDate.before (marsEnd75)) {mars = Sign.SCORPIO; }
        
        //Oct 20, 1995 4:02 PM Mars enters Sagittarius
        Date marsBegin76 = sdf.parse ("10/19/1995");
        Date marsEnd76 = sdf.parse ("11/30/1995");
        if (uDate.after (marsBegin76) && uDate.before (marsEnd76)) {mars = Sign.SAGITTARIUS; }
        
        //Nov 30, 1995 8:57 AM Mars enters Capricorn
        Date marsBegin77 = sdf.parse ("11/29/1995");
        Date marsEnd77 = sdf.parse ("01/08/1996");
        if (uDate.after (marsBegin77) && uDate.before (marsEnd77)) {mars = Sign.CAPRICORN; }     
        
        //Jan 8, 1996 6:02 AM Mars enters Aquarius
        Date marsBegin78 = sdf.parse ("01/07/1996");
        Date marsEnd78 = sdf.parse ("02/15/1996");
        if (uDate.after (marsBegin78) && uDate.before (marsEnd78)) {mars = Sign.AQUARIUS; }
        
        //Feb 15, 1996 6:50 AM Mars enters Pisces
        Date marsBegin79 = sdf.parse ("02/14/1996");
        Date marsEnd79 = sdf.parse ("03/24/1996");
        if (uDate.after (marsBegin79) && uDate.before (marsEnd79)) {mars = Sign.PISCES; }
        
        //Mar 24, 1996 10:12 AM Mars enters Aries
        Date marsBegin80 = sdf.parse ("03/23/1996");
        Date marsEnd80 = sdf.parse ("05/02/1996");
        if (uDate.after (marsBegin80) && uDate.before (marsEnd80)) {mars = Sign.ARIES; }
        
        //May 2, 1996 1:16 PM Mars enters Taurus
        Date marsBegin81 = sdf.parse ("05/01/1996");
        Date marsEnd81 = sdf.parse ("06/12/1996");
        if (uDate.after (marsBegin81) && uDate.before (marsEnd81)) {mars = Sign.TAURUS; }
        
        //June 12, 1996 9:42 AM Mars enters Gemini
        Date marsBegin82 = sdf.parse ("06/11/1996");
        Date marsEnd82 = sdf.parse ("07/25/1996");
        if (uDate.after (marsBegin82) && uDate.before (marsEnd82)) {mars = Sign.GEMINI; }
        
        //July 25, 1996 1:32 PM Mars enters Cancer
        Date marsBegin83 = sdf.parse ("07/24/1996");
        Date marsEnd83 = sdf.parse ("09/09/1996");
        if (uDate.after (marsBegin83) && uDate.before (marsEnd83)) {mars = Sign.CANCER; }
        
        //Sep 9, 1996 3:02 PM Mars enters Leo
        Date marsBegin84 = sdf.parse ("09/08/1996");
        Date marsEnd84 = sdf.parse ("10/30/1996");
        if (uDate.after (marsBegin84) && uDate.before (marsEnd84)) {mars = Sign.LEO; }
        
        //Oct 30, 1996 2:13 AM Mars enters Virgo
        Date marsBegin85 = sdf.parse ("10/29/1996");
        Date marsEnd85 = sdf.parse ("01/03/1997");
        if (uDate.after (marsBegin85) && uDate.before (marsEnd85)) {mars = Sign.VIRGO; }
        
        //Jan 3, 1997 3:10 AM Mars enters Libra
        Date marsBegin86 = sdf.parse ("01/02/1997");
        Date marsEnd86 = sdf.parse ("03/08/1997");
        if (uDate.after (marsBegin86) && uDate.before (marsEnd86)) {mars = Sign.LIBRA; }
        
        //Mar 8, 1997 2:49 PM Mars Rx enters Virgo
        Date marsBegin87 = sdf.parse ("03/07/1997");
        Date marsEnd87 = sdf.parse ("06/19/1997");
        if (uDate.after (marsBegin87) && uDate.before (marsEnd87)) {mars = Sign.VIRGO; }
        
        //June 19, 1997 3:30 AM Mars enters Libra
        Date marsBegin88 = sdf.parse ("06/18/1997");
        Date marsEnd88 = sdf.parse ("08/14/1997");
        if (uDate.after (marsBegin88) && uDate.before (marsEnd88)) {mars = Sign.LIBRA; }
       
        //Aug 14, 1997 3:42 AM Mars enters Scorpio
        Date marsBegin89 = sdf.parse ("08/13/1997");
        Date marsEnd89 = sdf.parse ("09/28/1997");
        if (uDate.after (marsBegin89) && uDate.before (marsEnd89)) {mars = Sign.SCORPIO; }
        
        //Sep 28, 1997 5:22 PM Mars enters Sagittarius
        Date marsBegin90 = sdf.parse ("09/27/1997");
        Date marsEnd90 = sdf.parse ("11/09/1997");
        if (uDate.after (marsBegin90) && uDate.before (marsEnd90)) {mars = Sign.SAGITTARIUS; }
        
        //Nov 9, 1997 12:33 AM Mars enters Capricorn
        Date marsBegin91 = sdf.parse ("11/08/1997");
        Date marsEnd91 = sdf.parse ("12/18/1997");
        if (uDate.after (marsBegin91) && uDate.before (marsEnd91)) {mars = Sign.CAPRICORN; }
        
        //Dec 18, 1997 1:37 AM Mars enters Aquarius
        Date marsBegin92 = sdf.parse ("12/17/1997");
        Date marsEnd92 = sdf.parse ("01/25/1998");
        if (uDate.after (marsBegin92) && uDate.before (marsEnd92)) {mars = Sign.AQUARIUS; }
        
        //Jan 25, 1998 4:26 AM Mars enters Pisces
        Date marsBegin93 = sdf.parse ("01/24/1998");
        Date marsEnd93 = sdf.parse ("03/04/1998");
        if (uDate.after (marsBegin93) && uDate.before (marsEnd93)) {mars = Sign.PISCES; }
        
        //Mar 4, 1998 11:18 AM Mars enters Aries
        Date marsBegin94 = sdf.parse ("03/03/1998");
        Date marsEnd94 = sdf.parse ("04/12/1998");
        if (uDate.after (marsBegin94) && uDate.before (marsEnd94)) {mars = Sign.ARIES; }        
        
        //Apr 12, 1998 8:04 PM Mars enters Taurus
        Date marsBegin95 = sdf.parse ("04/11/1998");
        Date marsEnd95 = sdf.parse ("05/23/1998");
        if (uDate.after (marsBegin95) && uDate.before (marsEnd95)) {mars = Sign.TAURUS; }        
        
        //May 23, 1998 10:42 PM Mars enters Gemini
        Date marsBegin96 = sdf.parse ("05/22/1998");
        Date marsEnd96 = sdf.parse ("07/06/1998");
        if (uDate.after (marsBegin96) && uDate.before (marsEnd96)) {mars = Sign.GEMINI; }        
        
        //July 6, 1998 4:00 AM Mars enters Cancer
        Date marsBegin97 = sdf.parse ("07/05/1998");
        Date marsEnd97 = sdf.parse ("08/20/1998");
        if (uDate.after (marsBegin97) && uDate.before (marsEnd97)) {mars = Sign.CANCER; }         
        
        //Aug 20, 1998 2:16 PM Mars enters Leo
        Date marsBegin98 = sdf.parse ("08/19/1998");
        Date marsEnd98 = sdf.parse ("10/07/1998");
        if (uDate.after (marsBegin98) && uDate.before (marsEnd98)) {mars = Sign.LEO; }
        
        //Oct 7, 1998 7:28 AM Mars enters Virgo
        Date marsBegin99 = sdf.parse ("10/06/1998");
        Date marsEnd99 = sdf.parse ("11/27/1998");
        if (uDate.after (marsBegin99) && uDate.before (marsEnd99)) {mars = Sign.VIRGO; }        
        
        //Nov 27, 1998 5:10 AM Mars enters Libra
        Date marsBegin100 = sdf.parse ("11/26/1998");
        Date marsEnd100 = sdf.parse ("01/26/1999");
        if (uDate.after (marsBegin100) && uDate.before (marsEnd100)) {mars = Sign.LIBRA; }        
        
        //Jan 26, 1999 6:59 AM Mars enters Scorpio
        Date marsBegin101 = sdf.parse ("01/25/1999");
        Date marsEnd101 = sdf.parse ("03/05/1999");
        if (uDate.after (marsBegin101) && uDate.before (marsEnd101)) {mars = Sign.SCORPIO; }         
        
        //May 5, 1999 4:32 PM Mars Rx enters Libra
        Date marsBegin102 = sdf.parse ("03/04/1999");
        Date marsEnd102 = sdf.parse ("07/04/1999");
        if (uDate.after (marsBegin102) && uDate.before (marsEnd102)) {mars = Sign.LIBRA; }
        
        //July 4, 1999 10:59 PM Mars enters Scorpio
        Date marsBegin103 = sdf.parse ("07/03/1999");
        Date marsEnd103 = sdf.parse ("09/02/1999");
        if (uDate.after (marsBegin103) && uDate.before (marsEnd103)) {mars = Sign.SCORPIO; }        
        
        //Sep 2, 1999 2:29 PM Mars enters Sagittarius
        Date marsBegin104 = sdf.parse ("09/01/1999");
        Date marsEnd104 = sdf.parse ("10/16/1999");
        if (uDate.after (marsBegin104) && uDate.before (marsEnd104)) {mars = Sign.SAGITTARIUS; }        
        
        //Oct 16, 1999 8:35 PM Mars enters Capricorn
        Date marsBegin105 = sdf.parse ("10/15/1999");
        Date marsEnd105 = sdf.parse ("11/26/1999");
        if (uDate.after (marsBegin105) && uDate.before (marsEnd105)) {mars = Sign.CAPRICORN; }        
        
        //Nov 26, 1999 1:56 AM Mars enters Aquarius
        Date marsBegin106 = sdf.parse ("11/25/1999");
        Date marsEnd106 = sdf.parse ("01/03/2000");
        if (uDate.after (marsBegin106) && uDate.before (marsEnd106)) {mars = Sign.AQUARIUS; }         
        
        //Jan 3, 2000 10:01 PM Mars enters Pisces
        Date marsBegin107 = sdf.parse ("01/02/2000");
        Date marsEnd107 = sdf.parse ("02/11/2000");
        if (uDate.after (marsBegin107) && uDate.before (marsEnd107)) {mars = Sign.PISCES; }
        
        //Feb 11, 2000 8:04 PM Mars enters Aries
        Date marsBegin108 = sdf.parse ("02/10/2000");
        Date marsEnd108 = sdf.parse ("03/22/2000");
        if (uDate.after (marsBegin108) && uDate.before (marsEnd108)) {mars = Sign.ARIES; }
        
        //Mar 22, 2000 8:25 PM Mars enters Taurus
        Date marsBegin109 = sdf.parse ("03/21/2000");
        Date marsEnd109 = sdf.parse ("05/03/2000");
        if (uDate.after (marsBegin109) && uDate.before (marsEnd109)) {mars = Sign.TAURUS; }
        
        //May 3, 2000 2:18 PM Mars enters Gemini
        Date marsBegin110 = sdf.parse ("05/02/2000");
        Date marsEnd110 = sdf.parse ("06/16/2000");
        if (uDate.after (marsBegin110) && uDate.before (marsEnd110)) {mars = Sign.GEMINI; }        
        
        //June 16, 2000 7:29 AM Mars enters Cancer
        Date marsBegin111 = sdf.parse ("06/15/2000");
        Date marsEnd111 = sdf.parse ("07/31/2000");
        if (uDate.after (marsBegin111) && uDate.before (marsEnd111)) {mars = Sign.CANCER; }        
        
        //July 31, 2000 8:21 PM Mars enters Leo
        Date marsBegin112 = sdf.parse ("07/30/2000");
        Date marsEnd112 = sdf.parse ("09/16/2000");
        if (uDate.after (marsBegin112) && uDate.before (marsEnd112)) {mars = Sign.LEO; }         
        
        //Sep 16, 2000 7:19 PM Mars enters Virgo
        Date marsBegin113 = sdf.parse ("09/15/2000");
        Date marsEnd113 = sdf.parse ("11/03/2000");
        if (uDate.after (marsBegin113) && uDate.before (marsEnd113)) {mars = Sign.VIRGO; } 
        
        //Nov 3, 2000 9:00 PM Mars enters Libra
        Date marsBegin114 = sdf.parse ("11/02/2000");
        Date marsEnd114 = sdf.parse ("12/23/2000");
        if (uDate.after (marsBegin114) && uDate.before (marsEnd114)) {mars = Sign.LIBRA; }
        
        //Dec 23, 2000 9:37 AM Mars enters Scorpio
        Date marsBegin115 = sdf.parse ("12/22/2000");
        Date marsEnd115 = sdf.parse ("02/14/2001");
        if (uDate.after (marsBegin115) && uDate.before (marsEnd115)) {mars = Sign.SCORPIO; }
        
        //Feb 14, 2001 3:06 PM Mars enters Sagittarius
        
    }//end setMars
    
    /* Venus (WORKS, mostly done: missing some dates)
        - list of venus days/times found at https://cafeastrology.com/venussignstables.html
        - right now, the time component of venus signs is not implemented
        - dates are limited from 1985 - 2000 */
    private void setVenus (String gDate) throws ParseException {
        Date uDate;
        SimpleDateFormat sdf = new SimpleDateFormat ("MM/dd/yyyy");
        uDate = sdf.parse(gDate); 

        //Dec 8, 1984 10:26 pm Venus enters Aquarius
        Date venusBegin1 = sdf.parse("12/07/1984");
        Date venusEnd1 = sdf.parse("01/04/1985");
        if (uDate.after(venusBegin1) && uDate.before(venusEnd1)) { venus = Sign.AQUARIUS;}
        
        //Jan 4, 1985 1:23 AM Venus enters Pisces
        Date venusBegin2 = sdf.parse("01/03/1985");
        Date venusEnd2 = sdf.parse("02/02/1985");
        if (uDate.after(venusBegin2) && uDate.before(venusEnd2)) { venus = Sign.PISCES;}
        
        //Feb 2, 1985 3:29 AM Venus enters Aries
        Date venusBegin3 = sdf.parse("02/01/1985");
        Date venusEnd3 = sdf.parse("06/06/1985");
        if (uDate.after(venusBegin3) && uDate.before(venusEnd3)) { venus = Sign.ARIES;}
        
        //June 6, 1985 3:53 AM Venus enters Taurus
        Date venusBegin4 = sdf.parse("06/05/1985");
        Date venusEnd4 = sdf.parse("07/06/1985");
        if (uDate.after(venusBegin4) && uDate.before(venusEnd4)) { venus = Sign.TAURUS;}
        
        //July 6, 1985 3:01 AM Venus enters Gemini
        Date venusBegin5 = sdf.parse("07/05/1985");
        Date venusEnd5 = sdf.parse("08/02/1985");
        if (uDate.after(venusBegin5) && uDate.before(venusEnd5)) { venus = Sign.GEMINI;}
        
        //Aug 2, 1985 4:10 AM Venus enters Cancer
        Date venusBegin6 = sdf.parse("08/01/1985");
        Date venusEnd6 = sdf.parse("08/27/1985");
        if (uDate.after(venusBegin6) && uDate.before(venusEnd6)) { venus = Sign.CANCER;}
        
        //Aug 27, 1985 10:39 PM Venus enters Leo
        Date venusBegin7 = sdf.parse("08/26/1985");
        Date venusEnd7 = sdf.parse("09/21/1985");
        if (uDate.after(venusBegin7) && uDate.before(venusEnd7)) { venus = Sign.LEO;}
        
        //Sep 21, 1985 9:53 PM Venus enters Virgo
        Date venusBegin8 = sdf.parse("09/20/1985");
        Date venusEnd8 = sdf.parse("10/16/1985");
        if (uDate.after(venusBegin8) && uDate.before(venusEnd8)) { venus = Sign.VIRGO;}
        
        //Oct 16, 1985 8:04 AM Venus enters Libra
        Date venusBegin9 = sdf.parse("10/15/1985");
        Date venusEnd9 = sdf.parse("11/09/1985");
        if (uDate.after(venusBegin9) && uDate.before(venusEnd9)) { venus = Sign.LIBRA;}
        
        //Nov 9, 1985 10:08 AM Venus enters Scorpio
        Date venusBegin10 = sdf.parse("11/08/1985");
        Date venusEnd10 = sdf.parse("12/03/1985");
        if (uDate.after(venusBegin10) && uDate.before(venusEnd10)) { venus = Sign.SCORPIO;}
        
        //Dec 3, 1985 8:00 AM Venus enters Sagittarius
        Date venusBegin11 = sdf.parse("12/02/1985");
        Date venusEnd11 = sdf.parse("12/27/1985");
        if (uDate.after(venusBegin11) && uDate.before(venusEnd11)) { venus = Sign.SAGITTARIUS;}
        
        //Dec 27, 1985 4:17 AM Venus enters Capricorn
        Date venusBegin12 = sdf.parse("12/26/1985");
        Date venusEnd12 = sdf.parse("01/20/1986");
        if (uDate.after(venusBegin12) && uDate.before(venusEnd12)) { venus = Sign.CAPRICORN;}
        
        //Jan 20, 1986 12:36 AM Venus enters Aquarius
        Date venusBegin13 = sdf.parse("01/19/1986");
        Date venusEnd13 = sdf.parse("02/12/1986");
        if (uDate.after(venusBegin13) && uDate.before(venusEnd13)) { venus = Sign.AQUARIUS;}
        
        //Feb 12, 1986 10:11 PM Venus enters Pisces
        Date venusBegin14 = sdf.parse("02/11/1986");
        Date venusEnd14 = sdf.parse("03/08/1986");
        if (uDate.after(venusBegin14) && uDate.before(venusEnd14)) { venus = Sign.PISCES;}
        
        //Mar 8, 1986 10:32 PM Venus enters Aries
        Date venusBegin15 = sdf.parse("03/07/1986");
        Date venusEnd15 = sdf.parse("04/02/1986");
        if (uDate.after(venusBegin15) && uDate.before(venusEnd15)) { venus = Sign.ARIES;}
        
        //Apr 2, 1986 3:19 AM Venus enters Taurus
        Date venusBegin16 = sdf.parse("04/01/1986");
        Date venusEnd16 = sdf.parse("04/26/1986");
        if (uDate.after(venusBegin16) && uDate.before(venusEnd16)) { venus = Sign.TAURUS;}
        
        //Apr 26, 1986 2:10 PM Venus enters Gemini
        Date venusBegin17 = sdf.parse("04/25/1986");
        Date venusEnd17 = sdf.parse("05/21/1986");
        if (uDate.after(venusBegin17) && uDate.before(venusEnd17)) { venus = Sign.GEMINI;}
        
        //May 21, 1986 8:46 AM Venus enters Cancer
        Date venusBegin18 = sdf.parse("05/20/1986");
        Date venusEnd18 = sdf.parse("06/15/1986");
        if (uDate.after(venusBegin18) && uDate.before(venusEnd18)) { venus = Sign.CANCER;}
        
        //June 15, 1986 1:52 PM Venus enters Leo
        Date venusBegin19 = sdf.parse("06/14/1986");
        Date venusEnd19 = sdf.parse("07/11/1986");
        if (uDate.after(venusBegin19) && uDate.before(venusEnd19)) { venus = Sign.LEO;}
        
        //July 11, 1986 11:23 AM Venus enters Virgo
        Date venusBegin20 = sdf.parse("07/10/1986");
        Date venusEnd20 = sdf.parse("08/07/1986");
        if (uDate.after(venusBegin20) && uDate.before(venusEnd20)) { venus = Sign.VIRGO;}
        
        //Aug 7, 1986 3:46 PM Venus enters Libra
        Date venusBegin21 = sdf.parse("08/06/1986");
        Date venusEnd21 = sdf.parse("09/07/1986");
        if (uDate.after(venusBegin21) && uDate.before(venusEnd21)) { venus = Sign.LIBRA;}
        
        //Sep 7, 1986 5:15 AM Venus enters Scorpio
        Date venusBegin22 = sdf.parse("09/06/1986");
        Date venusEnd22 = sdf.parse("01/07/1987");
        if (uDate.after(venusBegin22) && uDate.before(venusEnd22)) { venus = Sign.SCORPIO;}
        
        //Jan 7, 1987 5:20 AM Venus enters Sagittarius
        Date venusBegin23 = sdf.parse("01/06/1987");
        Date venusEnd23 = sdf.parse("02/04/1987");
        if (uDate.after(venusBegin23) && uDate.before(venusEnd23)) { venus = Sign.SAGITTARIUS;}
        
        //Feb 4, 1987 10:03 PM Venus enters Capricorn
        Date venusBegin24 = sdf.parse("02/03/1987");
        Date venusEnd24 = sdf.parse("03/03/1987");
        if (uDate.after(venusBegin24) && uDate.before(venusEnd24)) { venus = Sign.CAPRICORN;}
        
        //Mar 3, 1987 2:55 AM Venus enters Aquarius
        Date venusBegin25 = sdf.parse("03/02/1987");
        Date venusEnd25 = sdf.parse("03/28/1987");
        if (uDate.after(venusBegin25) && uDate.before(venusEnd25)) { venus = Sign.AQUARIUS;}
        
        //Mar 28, 1987 11:20 AM Venus enters Pisces
        Date venusBegin26 = sdf.parse("03/27/1987");
        Date venusEnd26 = sdf.parse("04/22/1987");
        if (uDate.after(venusBegin26) && uDate.before(venusEnd26)) { venus = Sign.PISCES;}
        
        //Apr 22, 1987 11:07 AM Venus enters Aries
        Date venusBegin27 = sdf.parse("04/21/1987");
        Date venusEnd27 = sdf.parse("05/17/1987");
        if (uDate.after(venusBegin27) && uDate.before(venusEnd27)) { venus = Sign.ARIES;}
        
        //May 17, 1987 6:56 AM Venus enters Taurus
        Date venusBegin28 = sdf.parse("05/16/1987");
        Date venusEnd28 = sdf.parse("06/11/1987");
        if (uDate.after(venusBegin28) && uDate.before(venusEnd28)) { venus = Sign.TAURUS;}
        
        //June 11, 1987 12:15 AM Venus enters Gemini
        Date venusBegin29 = sdf.parse("06/10/1987");
        Date venusEnd29 = sdf.parse("07/05/1987");
        if (uDate.after(venusBegin29) && uDate.before(venusEnd29)) { venus = Sign.GEMINI;}
        
        //July 5, 1987 2:50 PM Venus enters Cancer
        Date venusBegin30 = sdf.parse("07/04/1987");
        Date venusEnd30 = sdf.parse("07/30/1987");
        if (uDate.after(venusBegin30) && uDate.before(venusEnd30)) { venus = Sign.CANCER;}
        
        //July 30, 1987 1:49 AM Venus enters Leo
        Date venusBegin31 = sdf.parse("07/29/1987");
        Date venusEnd31 = sdf.parse("08/23/1987");
        if (uDate.after(venusBegin31) && uDate.before(venusEnd31)) { venus = Sign.LEO;}
        
        //Aug 23, 1987 9:00 AM Venus enters Virgo
        Date venusBegin32 = sdf.parse("08/22/1987");
        Date venusEnd32 = sdf.parse("09/16/1987");
        if (uDate.after(venusBegin32) && uDate.before(venusEnd32)) { venus = Sign.VIRGO;}
        
        //Sep 16, 1987 1:12 PM Venus enters Libra
        Date venusBegin33 = sdf.parse("09/15/1987");
        Date venusEnd33 = sdf.parse("10/10/1987");
        if (uDate.after(venusBegin33) && uDate.before(venusEnd33)) { venus = Sign.LIBRA;}
        
        //Oct 10, 1987 3:49 PM Venus enters Scorpio
        Date venusBegin34 = sdf.parse("10/09/1987");
        Date venusEnd34 = sdf.parse("11/03/1987");
        if (uDate.after(venusBegin34) && uDate.before(venusEnd34)) { venus = Sign.SCORPIO;}
        
        //Nov 3, 1987 6:04 PM Venus enters Sagittarius
        Date venusBegin35 = sdf.parse("11/02/1987");
        Date venusEnd35 = sdf.parse ("11/27/1987");
        if (uDate.after(venusBegin35) && uDate.before(venusEnd35)) {venus = Sign.SAGITTARIUS;}
        
        //Nov 27, 1987 8:51 PM Venus enters Capricorn
        Date venusBegin36 = sdf.parse("11/26/1987");
        Date venusEnd36 = sdf.parse ("12/22/1987");
        if (uDate.after(venusBegin36) && uDate.before(venusEnd36)) {venus = Sign.CAPRICORN;}
        
        //Dec 22, 1987 1:29 AM Venus enters Aquarius
        Date venusBegin37 = sdf.parse("12/21/1987");
        Date venusEnd37 = sdf.parse ("01/15/1988");
        if (uDate.after(venusBegin37) && uDate.before(venusEnd37)) {venus = Sign.AQUARIUS;}
        
        //Jan 15, 1988 11:04 AM Venus enters Pisces FINISHED EDITING HERE
        Date venusBegin38 = sdf.parse("01/14/1988");
        Date venusEnd38 = sdf.parse ("02/09/1988");
        if (uDate.after(venusBegin38) && uDate.before(venusEnd38)) {venus = Sign.PISCES;}
        
        //Feb 9, 1988 8:04 AM Venus enters Aries
        Date venusBegin39 = sdf.parse("02/08/1988");
        Date venusEnd39 = sdf.parse ("03/06/1988");
        if (uDate.after(venusBegin39) && uDate.before(venusEnd39)) {venus = Sign.ARIES;}
        
        //Mar 6, 1988 5:21 AM Venus enters Taurus
        Date venusBegin40 = sdf.parse("03/05/1988");
        Date venusEnd40 = sdf.parse ("04/03/1988");
        if (uDate.after(venusBegin40) && uDate.before(venusEnd40)) {venus = Sign.TAURUS;}
        
        //Apr 3, 1988 12:07 PM Venus enters Gemini
        Date venusBegin41 = sdf.parse("04/02/1988");
        Date venusEnd41 = sdf.parse ("05/17/1988");
        if (uDate.after(venusBegin41) && uDate.before(venusEnd41)) {venus = Sign.GEMINI;}
        
        //May 17, 1988 11:26 AM Venus enters Cancer
        Date venusBegin42 = sdf.parse("05/16/1988");
        Date venusEnd42 = sdf.parse ("05/27/1988");
        if (uDate.after(venusBegin42) && uDate.before(venusEnd42)) {venus = Sign.CANCER;}
        
        //May 27, 1988 2:36 AM Venus Rx enters Gemini
        Date venusBegin43 = sdf.parse("05/26/1988");
        Date venusEnd43 = sdf.parse ("08/06/1988");
        if (uDate.after(venusBegin43) && uDate.before(venusEnd43)) {venus = Sign.GEMINI;}
        
        //Aug 6, 1988 6:24 PM Venus enters Cancer
        Date venusBegin44 = sdf.parse("08/05/1988");
        Date venusEnd44 = sdf.parse ("09/07/1988");
        if (uDate.after(venusBegin44) && uDate.before(venusEnd44)) {venus = Sign.CANCER;}
        
        //Sep 7, 1988 6:37 AM Venus enters Leo
        Date venusBegin45 = sdf.parse("09/06/1988");
        Date venusEnd45 = sdf.parse ("10/04/1988");
        if (uDate.after(venusBegin45) && uDate.before(venusEnd45)) {venus = Sign.LEO;}
        
        //Oct 4, 1988 8:15 AM Venus enters Virgo
        Date venusBegin46 = sdf.parse("10/03/1988");
        Date venusEnd46 = sdf.parse ("10/29/1988");
        if (uDate.after(venusBegin46) && uDate.before(venusEnd46)) {venus = Sign.VIRGO;}
        
        //Oct 29, 1988 6:20 PM Venus enters Libra
        Date venusBegin47 = sdf.parse("10/28/1988");
        Date venusEnd47 = sdf.parse ("11/23/1988");
        if (uDate.after(venusBegin47) && uDate.before(venusEnd47)) {venus = Sign.LIBRA;}
        
        //Nov 23, 1988 8:34 AM Venus enters Scorpio
        Date venusBegin48 = sdf.parse("11/22/1988");
        Date venusEnd48 = sdf.parse ("12/17/1988");
        if (uDate.after(venusBegin48) && uDate.before(venusEnd48)) {venus = Sign.SCORPIO;}
        
        //Dec 17, 1988 12:56 PM Venus enters Sagittarius
        Date venusBegin49 = sdf.parse("12/16/1988");
        Date venusEnd49 = sdf.parse ("01/10/1989");
        if (uDate.after(venusBegin49) && uDate.before(venusEnd49)) {venus = Sign.SAGITTARIUS;}
        
        //Jan 10, 1989 1:08 PM Venus enters Capricorn
        Date venusBegin50 = sdf.parse("01/09/1989");
        Date venusEnd50 = sdf.parse ("02/03/1989");
        if (uDate.after(venusBegin50) && uDate.before(venusEnd50)) {venus = Sign.CAPRICORN;}
        
        //Feb 3, 1989 12:15 PM Venus enters Aquarius
        Date venusBegin51 = sdf.parse("02/02/1989");
        Date venusEnd51 = sdf.parse ("02/27/1989");
        if (uDate.after(venusBegin51) && uDate.before(venusEnd51)) {venus = Sign.AQUARIUS;}
        
        //Feb 27, 1989 11:59 AM Venus enters Pisces
        Date venusBegin52 = sdf.parse("02/26/1989");
        Date venusEnd52 = sdf.parse ("03/23/1989");
        if (uDate.after(venusBegin52) && uDate.before(venusEnd52)) {venus = Sign.PISCES;}
        
        //Mar 23, 1989 1:32 PM Venus enters Aries
        Date venusBegin53 = sdf.parse("03/22/1989");
        Date venusEnd53 = sdf.parse ("04/16/1989");
        if (uDate.after(venusBegin53) && uDate.before(venusEnd53)) {venus = Sign.ARIES;}
        
        //Apr 16, 1989 5:52 PM Venus enters Taurus
        Date venusBegin54 = sdf.parse("04/15/1989");
        Date venusEnd54 = sdf.parse ("05/11/1989");
        if (uDate.after(venusBegin54) && uDate.before(venusEnd54)) {venus = Sign.TAURUS;}
        
        //May 11, 1989 1:28 AM Venus enters Gemini
        Date venusBegin55 = sdf.parse("05/10/1989");
        Date venusEnd55 = sdf.parse ("06/04/1989");
        if (uDate.after(venusBegin55) && uDate.before(venusEnd55)) {venus = Sign.GEMINI;}
        
        //June 4, 1989 12:17 PM Venus enters Cancer
        Date venusBegin56 = sdf.parse("06/03/1989");
        Date venusEnd56 = sdf.parse ("06/29/1989");
        if (uDate.after(venusBegin56) && uDate.before(venusEnd56)) {venus = Sign.CANCER;}
        
        //June 29, 1989 2:21 AM Venus enters Leo
        Date venusBegin57 = sdf.parse("06/28/1989");
        Date venusEnd57 = sdf.parse ("07/23/1989");
        if (uDate.after(venusBegin57) && uDate.before(venusEnd57)) {venus = Sign.LEO;}
        
        //July 23, 1989 8:31 PM Venus enters Virgo
        Date venusBegin58 = sdf.parse("07/22/1989");
        Date venusEnd58 = sdf.parse ("08/17/1989");
        if (uDate.after(venusBegin58) && uDate.before(venusEnd58)) {venus = Sign.VIRGO;}
        
        //Aug 17, 1989 8:58 PM Venus enters Libra
        Date venusBegin59 = sdf.parse("08/16/1989");
        Date venusEnd59 = sdf.parse ("09/12/1989");
        if (uDate.after(venusBegin59) && uDate.before(venusEnd59)) {venus = Sign.LIBRA;}
        
        //Sep 12, 1989 7:22 AM Venus enters Scorpio
        Date venusBegin60 = sdf.parse("09/11/1989");
        Date venusEnd60 = sdf.parse ("10/08/1989");
        if (uDate.after(venusBegin60) && uDate.before(venusEnd60)) {venus = Sign.SCORPIO;}
        
        //Oct 8, 1989 11:00 AM Venus enters Sagittarius
        Date venusBegin61 = sdf.parse("10/07/1989");
        Date venusEnd61 = sdf.parse ("11/05/1989");
        if (uDate.after(venusBegin61) && uDate.before(venusEnd61)) {venus = Sign.SAGITTARIUS;}
        
        //Nov 5, 1989 5:13 AM Venus enters Capricorn
        Date venusBegin62 = sdf.parse("11/04/1989");
        Date venusEnd62 = sdf.parse ("12/10/1989");
        if (uDate.after(venusBegin62) && uDate.before(venusEnd62)) {venus = Sign.CAPRICORN;}
        
        //Dec 10, 1989 12:06 AM Venus enters Aquarius
        Date venusBegin63 = sdf.parse("12/09/1989");
        Date venusEnd63 = sdf.parse ("01/16/1990");
        if (uDate.after(venusBegin63) && uDate.before(venusEnd63)) {venus = Sign.AQUARIUS;}
        
        //Jan 16, 1990 10:23 AM Venus Rx enters Capricorn
        Date venusBegin64 = sdf.parse("01/15/1990");
        Date venusEnd64 = sdf.parse ("03/03/1990");
        if (uDate.after(venusBegin64) && uDate.before(venusEnd64)) {venus = Sign.CAPRICORN;}
        
        //Mar 3, 1990 12:52 PM Venus enters Aquarius
        Date venusBegin65 = sdf.parse("03/02/1990");
        Date venusEnd65 = sdf.parse ("04/06/1990");
        if (uDate.after(venusBegin65) && uDate.before(venusEnd65)) {venus = Sign.AQUARIUS;}

        //Apr 6, 1990 4:13 AM Venus enters Pisces
        Date venusBegin66 = sdf.parse("04/05/1990");
        Date venusEnd66 = sdf.parse ("05/03/1990");
        if (uDate.after(venusBegin66) && uDate.before(venusEnd66)) {venus = Sign.PISCES;}
        
        //May 3, 1990 10:52 PM Venus enters Aries
        Date venusBegin67 = sdf.parse("05/02/1990");
        Date venusEnd67 = sdf.parse ("05/30/1990");
        if (uDate.after(venusBegin67) && uDate.before(venusEnd67)) {venus = Sign.ARIES;}
        
        //May 30, 1990 5:13 AM Venus enters Taurus
        Date venusBegin68 = sdf.parse("05/29/1990");
        Date venusEnd68 = sdf.parse ("06/24/1990");
        if (uDate.after(venusBegin68) && uDate.before(venusEnd68)) {venus = Sign.TAURUS;}
        
        //June 24, 1990 7:14 PM Venus enters Gemini
        Date venusBegin69 = sdf.parse("06/23/1990");
        Date venusEnd69 = sdf.parse ("07/19/1990");
        if (uDate.after(venusBegin69) && uDate.before(venusEnd69)) {venus = Sign.GEMINI;}
        
        //July 19, 1990 10:41 PM Venus enters Cancer
        Date venusBegin70 = sdf.parse("07/18/1990");
        Date venusEnd70 = sdf.parse ("08/13/1990");
        if (uDate.after(venusBegin70) && uDate.before(venusEnd70)) {venus = Sign.CANCER;}
        
        //Aug 13, 1990 5:05 PM Venus enters Leo
        Date venusBegin71 = sdf.parse("08/12/1990");
        Date venusEnd71 = sdf.parse ("09/07/1990");
        if (uDate.after(venusBegin71) && uDate.before(venusEnd71)) {venus = Sign.LEO;}
        
        //Sep 7, 1990 3:21 AM Venus enters Virgo
        Date venusBegin72 = sdf.parse("09/06/1990");
        Date venusEnd72 = sdf.parse ("10/01/1990");
        if (uDate.after(venusBegin72) && uDate.before(venusEnd72)) {venus = Sign.VIRGO;}
        
        //Oct 1, 1990 7:13 AM Venus enters Libra
        Date venusBegin73 = sdf.parse("09/31/1990");
        Date venusEnd73 = sdf.parse ("10/25/1990");
        if (uDate.after(venusBegin73) && uDate.before(venusEnd73)) {venus = Sign.LIBRA;}  
        
        //Oct 25, 1990 7:03 AM Venus enters Scorpio
        Date venusBegin74 = sdf.parse("10/24/1990");
        Date venusEnd74 = sdf.parse ("11/18/1990");
        if (uDate.after(venusBegin74) && uDate.before(venusEnd74)) {venus = Sign.SCORPIO;}        
        
        //Nov 18, 1990 4:58 AM Venus enters Sagittarius
        Date venusBegin75 = sdf.parse("11/17/1990");
        Date venusEnd75 = sdf.parse ("12/12/1990");
        if (uDate.after(venusBegin75) && uDate.before(venusEnd75)) {venus = Sign.SAGITTARIUS;}
        
        //Dec 12, 1990 2:18 AM Venus enters Capricorn
        Date venusBegin76 = sdf.parse("12/11/1990");
        Date venusEnd76 = sdf.parse ("01/05/1991");
        if (uDate.after(venusBegin76) && uDate.before(venusEnd76)) {venus = Sign.CAPRICORN;}
        
        //Jan 5, 1991 12:03 AM Venus enters Aquarius
        Date venusBegin77 = sdf.parse("01/04/1991");
        Date venusEnd77 = sdf.parse ("01/28/1991");
        if (uDate.after(venusBegin77) && uDate.before(venusEnd77)) {venus = Sign.AQUARIUS;}
        
        //Jan 28, 1991 11:44 PM Venus enters Pisces
        Date venusBegin78 = sdf.parse("01/27/1991");
        Date venusEnd78 = sdf.parse ("02/22/1991");
        if (uDate.after(venusBegin78) && uDate.before(venusEnd78)) {venus = Sign.PISCES;}
        
        //Feb 22, 1991 4:02 AM Venus enters Aries
        Date venusBegin79 = sdf.parse("02/22/1991");
        Date venusEnd79 = sdf.parse ("03/18/1991");
        if (uDate.after(venusBegin79) && uDate.before(venusEnd79)) {venus = Sign.ARIES;}
        
        //Mar 18, 1991 4:45 PM Venus enters Taurus
        Date venusBegin80 = sdf.parse("03/17/1991");
        Date venusEnd80 = sdf.parse ("04/12/1991");
        if (uDate.after(venusBegin80) && uDate.before(venusEnd80)) {venus = Sign.TAURUS;}
        
        //Apr 12, 1991 7:10 PM Venus enters Gemini
        Date venusBegin81 = sdf.parse("04/11/1991");
        Date venusEnd81 = sdf.parse ("05/08/1991");
        if (uDate.after(venusBegin81) && uDate.before(venusEnd81)) {venus = Sign.GEMINI;}
        
        //May 8, 1991 8:28 PM Venus enters Cancer
        Date venusBegin82 = sdf.parse("05/07/1991");
        Date venusEnd82 = sdf.parse ("06/05/1991");
        if (uDate.after(venusBegin82) && uDate.before(venusEnd82)) {venus = Sign.CANCER;}
        
        //June 5, 1991 8:16 PM Venus enters Leo
        Date venusBegin83 = sdf.parse("06/04/1991");
        Date venusEnd83 = sdf.parse ("07/11/1991");
        if (uDate.after(venusBegin83) && uDate.before(venusEnd83)) {venus = Sign.LEO;}
        
        //July 11, 1991 12:06 AM Venus enters Virgo
        Date venusBegin84 = sdf.parse("07/10/1991");
        Date venusEnd84 = sdf.parse ("08/21/1991");
        if (uDate.after(venusBegin84) && uDate.before(venusEnd84)) {venus = Sign.VIRGO;}
        
        //Aug 21, 1991 10:06 AM Venus Rx enters Leo
        Date venusBegin85 = sdf.parse("08/20/1991");
        Date venusEnd85 = sdf.parse ("10/06/1991");
        if (uDate.after(venusBegin85) && uDate.before(venusEnd85)) {venus = Sign.LEO;}
        
        //Oct 6, 1991 4:15 PM Venus enters Virgo
        Date venusBegin86 = sdf.parse("10/05/1991");
        Date venusEnd86 = sdf.parse ("11/09/1991");
        if (uDate.after(venusBegin86) && uDate.before(venusEnd86)) {venus = Sign.VIRGO;}
        
        //Nov 9, 1991 1:37 AM Venus enters Libra
        Date venusBegin87 = sdf.parse("11/08/1991");
        Date venusEnd87 = sdf.parse ("12/06/1991");
        if (uDate.after(venusBegin87) && uDate.before(venusEnd87)) {venus = Sign.LIBRA;}
        
        //Dec 6, 1991 2:21 AM Venus enters Scorpio
        Date venusBegin88 = sdf.parse("12/05/1991");
        Date venusEnd88 = sdf.parse ("12/31/1991");
        if (uDate.after(venusBegin88) && uDate.before(venusEnd88)) {venus = Sign.SCORPIO;}
        
        //Dec 31, 1991 10:19 AM Venus enters Sagittarius
        Date venusBegin89 = sdf.parse("12/30/1991");
        Date venusEnd89 = sdf.parse ("01/25/1992");
        if (uDate.after(venusBegin89) && uDate.before(venusEnd89)) {venus = Sign.SAGITTARIUS;}
        
        //Jan 25, 1992 2:14 AM Venus enters Capricorn
        Date venusBegin90 = sdf.parse("01/24/1992");
        Date venusEnd90 = sdf.parse ("02/18/1992");
        if (uDate.after(venusBegin90) && uDate.before(venusEnd90)) {venus = Sign.CAPRICORN;}
        
        //Feb 18, 1992 11:40 AM Venus enters Aquarius
        Date venusBegin91 = sdf.parse("02/17/1992");
        Date venusEnd91 = sdf.parse ("03/13/1992");
        if (uDate.after(venusBegin91) && uDate.before(venusEnd91)) {venus = Sign.AQUARIUS;}
        
        //Mar 13, 1992 6:57 PM Venus enters Pisces
        Date venusBegin92 = sdf.parse("03/12/1992");
        Date venusEnd92 = sdf.parse ("04/07/1992");
        if (uDate.after(venusBegin92) && uDate.before(venusEnd92)) {venus = Sign.PISCES;}
        
        //Apr 7, 1992 2:16 AM Venus enters Aries
        Date venusBegin93 = sdf.parse("04/06/1992");
        Date venusEnd93 = sdf.parse ("05/01/1992");
        if (uDate.after(venusBegin93) && uDate.before(venusEnd93)) {venus = Sign.ARIES;}
        
        //May 1, 1992 10:41 AM Venus enters Taurus
        Date venusBegin94 = sdf.parse("04/31/1992");
        Date venusEnd94 = sdf.parse ("05/25/1992");
        if (uDate.after(venusBegin94) && uDate.before(venusEnd94)) {venus = Sign.TAURUS;}
        
        //May 25, 1992 8:18 PM Venus enters Gemini
        Date venusBegin95 = sdf.parse("05/24/1992");
        Date venusEnd95 = sdf.parse ("06/19/1992");
        if (uDate.after(venusBegin95) && uDate.before(venusEnd95)) {venus = Sign.GEMINI;}
        
        //June 19, 1992 6:22 AM Venus enters Cancer
        Date venusBegin96 = sdf.parse("06/18/1992");
        Date venusEnd96 = sdf.parse ("07/13/1992");
        if (uDate.after(venusBegin96) && uDate.before(venusEnd96)) {venus = Sign.CANCER;}
        
        //July 13, 1992 4:07 PM Venus enters Leo
        Date venusBegin97 = sdf.parse("07/12/1992");
        Date venusEnd97 = sdf.parse ("08/07/1992");
        if (uDate.after(venusBegin97) && uDate.before(venusEnd97)) {venus = Sign.LEO;}
        
        //Aug 7, 1992 1:26 AM Venus enters Virgo
        Date venusBegin98 = sdf.parse("08/06/1992");
        Date venusEnd98 = sdf.parse ("08/31/1992");
        if (uDate.after(venusBegin98) && uDate.before(venusEnd98)) {venus = Sign.VIRGO;}
        
        //Aug 31, 1992 11:09 AM Venus enters Libra
        Date venusBegin99 = sdf.parse("08/30/1992");
        Date venusEnd99 = sdf.parse ("07/24/1992");
        if (uDate.after(venusBegin99) && uDate.before(venusEnd99)) {venus = Sign.LIBRA;}
        
        //Sep 24, 1992 10:31 PM Venus enters Scorpio
        Date venusBegin100 = sdf.parse("07/23/1992");
        Date venusEnd100 = sdf.parse ("10/19/1992");
        if (uDate.after(venusBegin100) && uDate.before(venusEnd100)) {venus = Sign.SCORPIO;}
        
        //Oct 19, 1992 12:47 PM Venus enters Sagittarius
        Date venusBegin101 = sdf.parse("10/18/1992");
        Date venusEnd101 = sdf.parse ("11/13/1992");
        if (uDate.after(venusBegin101) && uDate.before(venusEnd101)) {venus = Sign.SAGITTARIUS;}      
        
        //Nov 13, 1992 7:48 AM Venus enters Capricorn
        Date venusBegin102 = sdf.parse("11/12/1992");
        Date venusEnd102 = sdf.parse ("12/08/1992");
        if (uDate.after(venusBegin102) && uDate.before(venusEnd102)) {venus = Sign.CAPRICORN;}  
        
        //Dec 8, 1992 12:49 PM Venus enters Aquarius
        Date venusBegin103 = sdf.parse("12/07/1992");
        Date venusEnd103 = sdf.parse ("01/03/1993");
        if (uDate.after(venusBegin103) && uDate.before(venusEnd103)) {venus = Sign.AQUARIUS;} 
        
        //Jan 3, 1993 6:54 PM Venus enters Pisces
        Date venusBegin104 = sdf.parse("01/02/1993");
        Date venusEnd104 = sdf.parse ("02/02/1993");
        if (uDate.after(venusBegin104) && uDate.before(venusEnd104)) {venus = Sign.PISCES;} 
        
        //Feb 2, 1993 7:37 AM Venus enters Aries
        Date venusBegin105 = sdf.parse("02/01/1993");
        Date venusEnd105 = sdf.parse ("06/06/1993");
        if (uDate.after(venusBegin105) && uDate.before(venusEnd105)) {venus = Sign.ARIES;}
        
        //June 6, 1993 5:03 AM Venus enters Taurus
        Date venusBegin106 = sdf.parse("06/05/1993");
        Date venusEnd106 = sdf.parse ("07/05/1993");
        if (uDate.after(venusBegin106) && uDate.before(venusEnd106)) {venus = Sign.TAURUS;}
        
        //July 5, 1993 7:21 PM Venus enters Gemini
        Date venusBegin107 = sdf.parse("07/04/1993");
        Date venusEnd107 = sdf.parse ("08/01/1993");
        if (uDate.after(venusBegin107) && uDate.before(venusEnd107)) {venus = Sign.GEMINI;}
        
        //Aug 1, 1993 5:38 PM Venus enters Cancer
        Date venusBegin108 = sdf.parse("07/31/1993");
        Date venusEnd108 = sdf.parse ("08/27/1993");
        if (uDate.after(venusBegin108) && uDate.before(venusEnd108)) {venus = Sign.CANCER;}
        
        //Aug 27, 1993 10:48 AM Venus enters Leo
        Date venusBegin109 = sdf.parse("08/26/1993");
        Date venusEnd109 = sdf.parse ("09/21/1993");
        if (uDate.after(venusBegin109) && uDate.before(venusEnd109)) {venus = Sign.LEO;}
        
        //Sep 21, 1993 9:22 AM Venus enters Virgo
        Date venusBegin110 = sdf.parse("09/20/1993");
        Date venusEnd110 = sdf.parse ("10/15/1993");
        if (uDate.after(venusBegin110) && uDate.before(venusEnd110)) {venus = Sign.VIRGO;}
        
        //Oct 15, 1993 7:13 PM Venus enters Libra
        Date venusBegin111 = sdf.parse("10/15/1993");
        Date venusEnd111 = sdf.parse ("11/08/1993");
        if (uDate.after(venusBegin111) && uDate.before(venusEnd111)) {venus = Sign.LIBRA;}
        
        //Nov 8, 1993 9:07 PM Venus enters Scorpio
        Date venusBegin112 = sdf.parse("11/07/1993");
        Date venusEnd112 = sdf.parse ("12/02/1993");
        if (uDate.after(venusBegin112) && uDate.before(venusEnd112)) {venus = Sign.SCORPIO;}
        
        //Dec 2, 1993 6:54 PM Venus enters Sagittarius
        Date venusBegin113 = sdf.parse("12/01/1993");
        Date venusEnd113 = sdf.parse ("12/26/1993");
        if (uDate.after(venusBegin113) && uDate.before(venusEnd113)) {venus = Sign.SAGITTARIUS;}
        
        //Dec 26, 1993 3:09 PM Venus enters Capricorn
        Date venusBegin114 = sdf.parse("12/25/1993");
        Date venusEnd114 = sdf.parse ("01/19/1994");
        if (uDate.after(venusBegin114) && uDate.before(venusEnd114)) {venus = Sign.CAPRICORN;}
        
        //Jan 19, 1994 11:28 AM Venus enters Aquarius
        Date venusBegin115 = sdf.parse("01/18/1994");
        Date venusEnd115 = sdf.parse ("02/12/1994");
        if (uDate.after(venusBegin115) && uDate.before(venusEnd115)) {venus = Sign.AQUARIUS;}
        
        //Feb 12, 1994 9:04 AM Venus enters Pisces
        Date venusBegin116 = sdf.parse("02/11/1994");
        Date venusEnd116 = sdf.parse ("03/08/1994");
        if (uDate.after(venusBegin116) && uDate.before(venusEnd116)) {venus = Sign.PISCES;}
        
        //Mar 8, 1994 9:28 AM Venus enters Aries
        Date venusBegin117 = sdf.parse("03/07/1994");
        Date venusEnd117 = sdf.parse ("04/01/1994");
        if (uDate.after(venusBegin117) && uDate.before(venusEnd117)) {venus = Sign.ARIES;}
        
        //Apr 1, 1994 2:20 PM Venus enters Taurus
        Date venusBegin118 = sdf.parse("03/31/1994");
        Date venusEnd118 = sdf.parse ("04/26/1994");
        if (uDate.after(venusBegin118) && uDate.before(venusEnd118)) {venus = Sign.TAURUS;}
        
        //Apr 26, 1994 1:24 AM Venus enters Gemini
        Date venusBegin119 = sdf.parse("04/25/1994");
        Date venusEnd119 = sdf.parse ("05/20/1994");
        if (uDate.after(venusBegin119) && uDate.before(venusEnd119)) {venus = Sign.GEMINI;}
        
        //May 20, 1994 8:26 PM Venus enters Cancer
        Date venusBegin120 = sdf.parse("05/19/1994");
        Date venusEnd120 = sdf.parse ("06/15/1994");
        if (uDate.after(venusBegin120) && uDate.before(venusEnd120)) {venus = Sign.CANCER;}
        
        //June 15, 1994 2:23 AM Venus enters Leo
        Date venusBegin121 = sdf.parse("06/14/1994");
        Date venusEnd121 = sdf.parse ("07/11/1994");
        if (uDate.after(venusBegin121) && uDate.before(venusEnd121)) {venus = Sign.LEO;} 
       
        //July 11, 1994 1:33 AM Venus enters Virgo
        Date venusBegin122 = sdf.parse("07/10/1994");
        Date venusEnd122 = sdf.parse ("08/07/1994");
        if (uDate.after(venusBegin122) && uDate.before(venusEnd122)) {venus = Sign.VIRGO;}
        
        //Aug 7, 1994 9:36 AM Venus enters Libra
        Date venusBegin123 = sdf.parse("08/06/1994");
        Date venusEnd123 = sdf.parse ("09/07/1994");
        if (uDate.after(venusBegin123) && uDate.before(venusEnd123)) {venus = Sign.LIBRA;}
        
        //Sep 7, 1994 12:12 PM Venus enters Scorpio
        Date venusBegin124 = sdf.parse("09/06/1994");
        Date venusEnd124 = sdf.parse ("01/07/1995");
        if (uDate.after(venusBegin124) && uDate.before(venusEnd124)) {venus = Sign.SCORPIO;}
        
        //Jan 7, 1995 7:07 AM Venus enters Sagittarius
        Date venusBegin125 = sdf.parse("01/06/1995");
        Date venusEnd125 = sdf.parse ("02/04/1995");
        if (uDate.after(venusBegin125) && uDate.before(venusEnd125)) {venus = Sign.SAGITTARIUS;}
        
        //Feb 4, 1995 3:12 PM Venus enters Capricorn
        Date venusBegin126 = sdf.parse("02/03/1995");
        Date venusEnd126 = sdf.parse ("03/02/1995");
        if (uDate.after(venusBegin126) && uDate.before(venusEnd126)) {venus = Sign.CAPRICORN;}
        
        //Mar 2, 1995 5:10 PM Venus enters Aquarius
        Date venusBegin127 = sdf.parse("03/01/1995");
        Date venusEnd127 = sdf.parse ("03/28/1995");
        if (uDate.after(venusBegin127) && uDate.before(venusEnd127)) {venus = Sign.AQUARIUS;}
        
        //Mar 28, 1995 12:10 AM Venus enters Pisces
        Date venusBegin128 = sdf.parse("03/27/1995");
        Date venusEnd128 = sdf.parse ("04/21/1995");
        if (uDate.after(venusBegin128) && uDate.before(venusEnd128)) {venus = Sign.PISCES;}
        
        //Apr 21, 1995 11:07 PM Venus enters Aries
        Date venusBegin129 = sdf.parse("04/20/1995");
        Date venusEnd129 = sdf.parse ("05/16/1995");
        if (uDate.after(venusBegin129) && uDate.before(venusEnd129)) {venus = Sign.ARIES;}
        
        //May 16, 1995 6:22 PM Venus enters Taurus
        Date venusBegin130 = sdf.parse("05/15/1995");
        Date venusEnd130 = sdf.parse ("06/10/1995");
        if (uDate.after(venusBegin130) && uDate.before(venusEnd130)) {venus = Sign.TAURUS;}
        
        //June 10, 1995 11:18 AM Venus enters Gemini
        Date venusBegin131 = sdf.parse("06/09/1995");
        Date venusEnd131 = sdf.parse ("07/05/1995");
        if (uDate.after(venusBegin131) && uDate.before(venusEnd131)) {venus = Sign.GEMINI;}
        
        //July 5, 1995 1:39 AM Venus enters Cancer
        Date venusBegin132 = sdf.parse("07/04/1995");
        Date venusEnd132 = sdf.parse ("07/29/1995");
        if (uDate.after(venusBegin132) && uDate.before(venusEnd132)) {venus = Sign.CANCER;}
        
        //July 29, 1995 12:32 PM Venus enters Leo
        Date venusBegin133 = sdf.parse("07/28/1995");
        Date venusEnd133 = sdf.parse ("08/22/1995");
        if (uDate.after(venusBegin133) && uDate.before(venusEnd133)) {venus = Sign.LEO;}
        
        //Aug 22, 1995 7:43 PM Venus enters Virgo
        Date venusBegin134 = sdf.parse("08/21/1995");
        Date venusEnd134 = sdf.parse ("09/16/1995");
        if (uDate.after(venusBegin134) && uDate.before(venusEnd134)) {venus = Sign.VIRGO;}
        
        //Sep 16, 1995 12:01 AM Venus enters Libra
        Date venusBegin135 = sdf.parse("09/15/1995");
        Date venusEnd135 = sdf.parse ("10/10/1995");
        if (uDate.after(venusBegin135) && uDate.before(venusEnd135)) {venus = Sign.LIBRA;}
        
        //Oct 10, 1995 2:48 AM Venus enters Scorpio
        Date venusBegin136 = sdf.parse("10/09/1995");
        Date venusEnd136 = sdf.parse ("11/03/1995");
        if (uDate.after(venusBegin136) && uDate.before(venusEnd136)) {venus = Sign.SCORPIO;}
        
        //Nov 3, 1995 5:18 AM Venus enters Sagittarius
        Date venusBegin137 = sdf.parse("11/02/1995");
        Date venusEnd137 = sdf.parse ("11/27/1995");
        if (uDate.after(venusBegin137) && uDate.before(venusEnd137)) {venus = Sign.SAGITTARIUS;}
        
        //Nov 27, 1995 8:23 AM Venus enters Capricorn
        Date venusBegin138 = sdf.parse("11/26/1995");
        Date venusEnd138 = sdf.parse ("12/21/1995");
        if (uDate.after(venusBegin138) && uDate.before(venusEnd138)) {venus = Sign.CAPRICORN;}
        
        //Dec 21, 1995 1:23 PM Venus enters Aquarius
        Date venusBegin139 = sdf.parse("12/20/1995");
        Date venusEnd139 = sdf.parse ("01/14/1996");
        if (uDate.after(venusBegin139) && uDate.before(venusEnd139)) {venus = Sign.AQUARIUS;}
        
        //Jan 14, 1996 11:30 PM Venus enters Pisces
        Date venusBegin140 = sdf.parse("01/13/1996");
        Date venusEnd140 = sdf.parse ("02/08/1996");
        if (uDate.after(venusBegin140) && uDate.before(venusEnd140)) {venus = Sign.PISCES;}
        
        //Feb 8, 1996 9:30 PM Venus enters Aries
        Date venusBegin141 = sdf.parse("02/07/1996");
        Date venusEnd141 = sdf.parse ("03/05/1996");
        if (uDate.after(venusBegin141) && uDate.before(venusEnd141)) {venus = Sign.ARIES;}
        
        //Mar 5, 1996 9:01 PM Venus enters Taurus
        Date venusBegin142 = sdf.parse("03/04/1996");
        Date venusEnd142 = sdf.parse ("04/03/1996");
        if (uDate.after(venusBegin142) && uDate.before(venusEnd142)) {venus = Sign.TAURUS;}
        
        //Apr 3, 1996 10:26 AM Venus enters Gemini
        Date venusBegin143 = sdf.parse("04/02/1996");
        Date venusEnd143 = sdf.parse ("08/07/1996");
        if (uDate.after(venusBegin143) && uDate.before(venusEnd143)) {venus = Sign.GEMINI;}
        
        //Aug 7, 1996 1:15 AM Venus enters Cancer
        Date venusBegin144 = sdf.parse("08/06/1996");
        Date venusEnd144 = sdf.parse ("09/07/1996");
        if (uDate.after(venusBegin144) && uDate.before(venusEnd144)) {venus = Sign.CANCER;}
        
        //Sept 7, 1996 12:07 AM Venus enters Leo
        Date venusBegin145 = sdf.parse("09/06/1996");
        Date venusEnd145 = sdf.parse ("10/03/1996");
        if (uDate.after(venusBegin145) && uDate.before(venusEnd145)) {venus = Sign.LEO;}
        
        //Oct 3, 1996 10:22 PM Venus enters Virgo
        Date venusBegin146 = sdf.parse("10/02/1996");
        Date venusEnd146 = sdf.parse ("10/29/1996");
        if (uDate.after(venusBegin146) && uDate.before(venusEnd146)) {venus = Sign.VIRGO;}
        
        //Oct 29, 1996 7:02 AM Venus enters Libra
        Date venusBegin147 = sdf.parse("10/28/1996");
        Date venusEnd147 = sdf.parse ("11/22/1996");
        if (uDate.after(venusBegin147) && uDate.before(venusEnd147)) {venus = Sign.LIBRA;}
        
        //Nov 22, 1996 8:34 PM Venus enters Scorpio
        Date venusBegin148 = sdf.parse("11/21/1996");
        Date venusEnd148 = sdf.parse ("12/17/1996");
        if (uDate.after(venusBegin148) && uDate.before(venusEnd148)) {venus = Sign.SCORPIO;}
        
        //Dec 17, 1996 12:34 AM Venus enters Sagittarius
        Date venusBegin149 = sdf.parse("12/16/1996");
        Date venusEnd149 = sdf.parse ("01/10/1997");
        if (uDate.after(venusBegin149) && uDate.before(venusEnd149)) {venus = Sign.SAGITTARIUS;}
        
        //Jan 10, 1997 12:32 AM Venus enters Capricorn
        Date venusBegin150 = sdf.parse("01/09/1997");
        Date venusEnd150 = sdf.parse ("02/02/1997");
        if (uDate.after(venusBegin150) && uDate.before(venusEnd150)) {venus = Sign.CAPRICORN;}
        
        //Feb 2, 1997 11:28 PM Venus enters Aquarius
        Date venusBegin151 = sdf.parse("02/01/1997");
        Date venusEnd151 = sdf.parse ("02/26/1997");
        if (uDate.after(venusBegin151) && uDate.before(venusEnd151)) {venus = Sign.AQUARIUS;}
        
        //Feb 26, 1997 11:01 PM Venus enters Pisces
         Date venusBegin152 = sdf.parse("02/25/1997");
        Date venusEnd152 = sdf.parse ("03/23/1997");
        if (uDate.after(venusBegin152) && uDate.before(venusEnd152)) {venus = Sign.PISCES;}
        
        //Mar 23, 1997 12:26 AM Venus enters Aries
         Date venusBegin153 = sdf.parse("03/22/1997");
        Date venusEnd153 = sdf.parse ("04/16/1997");
        if (uDate.after(venusBegin153) && uDate.before(venusEnd153)) {venus = Sign.ARIES;}
        
        //Apr 16, 1997 4:42 AM Venus enters Taurus
        Date venusBegin154 = sdf.parse("04/15/1997");
        Date venusEnd154 = sdf.parse ("05/10/1997");
        if (uDate.after(venusBegin154) && uDate.before(venusEnd154)) {venus = Sign.TAURUS;}
        
        //May 10, 1997 12:20 PM Venus enters Gemini
        Date venusBegin155 = sdf.parse("05/09/1997");
        Date venusEnd155 = sdf.parse ("06/03/1997");
        if (uDate.after(venusBegin155) && uDate.before(venusEnd155)) {venus = Sign.GEMINI;}
        
        //June 3, 1997 11:18 PM Venus enters Cancer
        Date venusBegin156 = sdf.parse("06/02/1997");
        Date venusEnd156 = sdf.parse ("06/28/1997");
        if (uDate.after(venusBegin156) && uDate.before(venusEnd156)) {venus = Sign.CANCER;}
        
        //June 28, 1997 1:38 PM Venus enters Leo
        Date venusBegin157 = sdf.parse("06/27/1997");
        Date venusEnd157 = sdf.parse ("07/23/1997");
        if (uDate.after(venusBegin157) && uDate.before(venusEnd157)) {venus = Sign.LEO;}
        
        //July 23, 1997 8:16 AM Venus enters Virgo
        Date venusBegin158 = sdf.parse("07/22/1997");
        Date venusEnd158 = sdf.parse ("08/17/1997");
        if (uDate.after(venusBegin158) && uDate.before(venusEnd158)) {venus = Sign.VIRGO;}
        
        //Aug 17, 1997 9:31 AM Venus enters Libra
        Date venusBegin159 = sdf.parse("08/16/1997");
        Date venusEnd159 = sdf.parse ("09/11/1997");
        if (uDate.after(venusBegin159) && uDate.before(venusEnd159)) {venus = Sign.LIBRA;}
        
        //Sep 11, 1997 9:17 PM Venus enters Scorpio
        Date venusBegin160 = sdf.parse("09/10/1997");
        Date venusEnd160 = sdf.parse ("10/08/1997");
        if (uDate.after(venusBegin160) && uDate.before(venusEnd160)) {venus = Sign.SCORPIO;}
        
        //Oct 8, 1997 3:25 AM Venus enters Sagittarius
        Date venusBegin161 = sdf.parse("10/07/1997");
        Date venusEnd161 = sdf.parse ("11/05/1997");
        if (uDate.after(venusBegin161) && uDate.before(venusEnd161)) {venus = Sign.SAGITTARIUS;}
        
        //Nov 5, 1997 3:50 AM Venus enters Capricorn
        Date venusBegin162 = sdf.parse("11/04/1997");
        Date venusEnd162 = sdf.parse ("12/11/1997");
        if (uDate.after(venusBegin162) && uDate.before(venusEnd162)) {venus = Sign.CAPRICORN;}
        
        //Dec 11, 1997 11:39 PM Venus enters Aquarius
        Date venusBegin163 = sdf.parse("12/10/1997");
        Date venusEnd163 = sdf.parse ("01/09/1998");
        if (uDate.after(venusBegin163) && uDate.before(venusEnd163)) {venus = Sign.AQUARIUS;}
        
        //Jan 9, 1998 4:03 PM Venus Rx enters Capricorn
        Date venusBegin164 = sdf.parse("01/08/1998");
        Date venusEnd164 = sdf.parse ("03/04/1998");
        if (uDate.after(venusBegin164) && uDate.before(venusEnd164)) {venus = Sign.CAPRICORN;}
        
        //Mar 4, 1998 11:14 AM Venus enters Aquarius
        Date venusBegin165 = sdf.parse("03/03/1998");
        Date venusEnd165 = sdf.parse ("04/06/1998");
        if (uDate.after(venusBegin165) && uDate.before(venusEnd165)) {venus = Sign.AQUARIUS;}
        
        //Apr 6, 1998 12:38 AM Venus enters Pisces
        Date venusBegin166 = sdf.parse("04/05/1998");
        Date venusEnd166 = sdf.parse ("05/03/1998");
        if (uDate.after(venusBegin166) && uDate.before(venusEnd166)) {venus = Sign.PISCES;}
        
        //May 3, 1998 2:16 PM Venus enters Aries
        Date venusBegin167 = sdf.parse("05/02/1998");
        Date venusEnd167 = sdf.parse ("05/29/1998");
        if (uDate.after(venusBegin167) && uDate.before(venusEnd167)) {venus = Sign.ARIES;}
        
        //May 29, 1998 6:32 PM Venus enters Taurus
        Date venusBegin168 = sdf.parse("05/28/1998");
        Date venusEnd168 = sdf.parse ("06/24/1998");
        if (uDate.after(venusBegin168) && uDate.before(venusEnd168)) {venus = Sign.TAURUS;}
        
        //June 24, 1998 7:27 AM Venus enters Gemini
        Date venusBegin169 = sdf.parse("06/23/1998");
        Date venusEnd169 = sdf.parse ("07/19/1998");
        if (uDate.after(venusBegin169) && uDate.before(venusEnd169)) {venus = Sign.GEMINI;}
        
        //July 19, 1998 10:17 AM Venus enters Cancer
        Date venusBegin170 = sdf.parse("07/18/1998");
        Date venusEnd170 = sdf.parse ("08/13/1998");
        if (uDate.after(venusBegin170) && uDate.before(venusEnd170)) {venus = Sign.CANCER;}
        
        //Aug 13, 1998 4:19 AM Venus enters Leo
        Date venusBegin171 = sdf.parse("08/12/1998");
        Date venusEnd171 = sdf.parse ("09/06/1998");
        if (uDate.after(venusBegin171) && uDate.before(venusEnd171)) {venus = Sign.LEO;}
        
        //Sep 6, 1998 2:24 PM Venus enters Virgo
        Date venusBegin172 = sdf.parse("09/05/1998");
        Date venusEnd172 = sdf.parse ("09/30/1998");
        if (uDate.after(venusBegin172) && uDate.before(venusEnd172)) {venus = Sign.VIRGO;}
        
        //Sep 30, 1998 6:13 PM Venus enters Libra
        Date venusBegin173 = sdf.parse("09/29/1998");
        Date venusEnd173 = sdf.parse ("10/24/1998");
        if (uDate.after(venusBegin173) && uDate.before(venusEnd173)) {venus = Sign.LIBRA;}
        
        //Oct 24, 1998 6:06 PM Venus enters Scorpio
        Date venusBegin174 = sdf.parse("10/23/1998");
        Date venusEnd174 = sdf.parse ("11/17/1998");
        if (uDate.after(venusBegin174) && uDate.before(venusEnd174)) {venus = Sign.SCORPIO;}
        
        //Nov 17, 1998 4:06 PM Venus enters Sagittarius
        Date venusBegin175 = sdf.parse("11/16/1998");
        Date venusEnd175 = sdf.parse ("12/11/1998");
        if (uDate.after(venusBegin175) && uDate.before(venusEnd175)) {venus = Sign.SAGITTARIUS;}
        
        //Dec 11, 1998 1:33 PM Venus enters Capricorn
        Date venusBegin176 = sdf.parse("12/10/1998");
        Date venusEnd176 = sdf.parse ("01/04/1999");
        if (uDate.after(venusBegin176) && uDate.before(venusEnd176)) {venus = Sign.CAPRICORN;}
        
        //Jan 4, 1999 11:25 AM Venus enters Aquarius
        Date venusBegin177 = sdf.parse("01/03/1999");
        Date venusEnd177 = sdf.parse ("01/28/1999");
        if (uDate.after(venusBegin177) && uDate.before(venusEnd177)) {venus = Sign.AQUARIUS;}
        
        //Jan 28, 1999 11:17 AM Venus enters Pisces
        Date venusBegin178 = sdf.parse("01/27/1999");
        Date venusEnd178 = sdf.parse ("02/21/1999");
        if (uDate.after(venusBegin178) && uDate.before(venusEnd178)) {venus = Sign.PISCES;}
        
        //Feb 21, 1999 3:49 PM Venus enters Aries
        Date venusBegin179 = sdf.parse("02/20/1999");
        Date venusEnd179 = sdf.parse ("03/18/1999");
        if (uDate.after(venusBegin179) && uDate.before(venusEnd179)) {venus = Sign.ARIES;}
        
        //Mar 18, 1999 4:59 AM Venus enters Taurus
        Date venusBegin180 = sdf.parse("03/17/1999");
        Date venusEnd180 = sdf.parse ("04/12/1999");
        if (uDate.after(venusBegin180) && uDate.before(venusEnd180)) {venus = Sign.TAURUS;}
        
        //Apr 12, 1999 8:17 AM Venus enters Gemini
        Date venusBegin181 = sdf.parse("04/11/1999");
        Date venusEnd181 = sdf.parse ("05/08/1999");
        if (uDate.after(venusBegin181) && uDate.before(venusEnd181)) {venus = Sign.GEMINI;}
        
        //May 8, 1999 11:29 AM Venus enters Cancer
        Date venusBegin182 = sdf.parse("05/07/1999");
        Date venusEnd182 = sdf.parse ("06/05/1999");
        if (uDate.after(venusBegin182) && uDate.before(venusEnd182)) {venus = Sign.CANCER;}
        
        //June 5, 1999 4:25 PM Venus enters Leo
        Date venusBegin183 = sdf.parse("06/04/1999");
        Date venusEnd183 = sdf.parse ("07/12/1999");
        if (uDate.after(venusBegin183) && uDate.before(venusEnd183)) {venus = Sign.LEO;}
        
        //July 12, 1999 10:18 AM Venus enters Virgo
        Date venusBegin184 = sdf.parse("07/11/1999");
        Date venusEnd184 = sdf.parse ("08/15/1999");
        if (uDate.after(venusBegin184) && uDate.before(venusEnd184)) {venus = Sign.VIRGO;}
        
        //Aug 15, 1999 9:12 AM Venus Rx enters Leo
        Date venusBegin185 = sdf.parse("08/14/1999");
        Date venusEnd185 = sdf.parse ("10/07/1999");
        if (uDate.after(venusBegin185) && uDate.before(venusEnd185)) {venus = Sign.LEO;}
        
        //Oct 7, 1999 11:51 AM Venus enters Virgo
        Date venusBegin186 = sdf.parse("10/06/1999");
        Date venusEnd186 = sdf.parse ("11/08/1999");
        if (uDate.after(venusBegin186) && uDate.before(venusEnd186)) {venus = Sign.VIRGO;}
        
        //Nov 8, 1999 9:19 PM Venus enters Libra
        Date venusBegin187 = sdf.parse("11/07/1999");
        Date venusEnd187 = sdf.parse ("12/05/1999");
        if (uDate.after(venusBegin187) && uDate.before(venusEnd187)) {venus = Sign.LIBRA;}
        
        //Dec 5, 1999 5:41 PM Venus enters Scorpio
        Date venusBegin188 = sdf.parse("12/04/1999");
        Date venusEnd188 = sdf.parse ("12/30/1999");
        if (uDate.after(venusBegin188) && uDate.before(venusEnd188)) {venus = Sign.SCORPIO;}
        
        //Dec 30, 1999 11:54 PM Venus enters Sagittarius
        Date venusBegin189 = sdf.parse("12/29/1999");
        Date venusEnd189 = sdf.parse ("01/24/2000");
        if (uDate.after(venusBegin189) && uDate.before(venusEnd189)) {venus = Sign.SAGITTARIUS;}
        
        //Jan 24, 2000 2:52 PM Venus enters Capricorn
        Date venusBegin190 = sdf.parse("01/23/2000");
        Date venusEnd190 = sdf.parse ("02/17/2000");
        if (uDate.after(venusBegin190) && uDate.before(venusEnd190)) {venus = Sign.CAPRICORN;}
        
        //Feb 17, 2000 11:43 PM Venus enters Aquarius
        Date venusBegin191 = sdf.parse("02/16/2000");
        Date venusEnd191 = sdf.parse ("03/13/2000");
        if (uDate.after(venusBegin191) && uDate.before(venusEnd191)) {venus = Sign.AQUARIUS;}
        
        //Mar 13, 2000 6:36 AM Venus enters Pisces
        Date venusBegin192 = sdf.parse("03/12/2000");
        Date venusEnd192 = sdf.parse ("04/06/2000");
        if (uDate.after(venusBegin192) && uDate.before(venusEnd192)) {venus = Sign.PISCES;}
        
        //Apr 6, 2000 1:37 PM Venus enters Aries
        Date venusBegin193 = sdf.parse("04/05/2000");
        Date venusEnd193 = sdf.parse ("04/30/2000");
        if (uDate.after(venusBegin193) && uDate.before(venusEnd193)) {venus = Sign.ARIES;}
        
        //Apr 30, 2000 9:49 PM Venus enters Taurus
        Date venusBegin194 = sdf.parse("04/29/2000");
        Date venusEnd194 = sdf.parse ("05/25/2000");
        if (uDate.after(venusBegin194) && uDate.before(venusEnd194)) {venus = Sign.TAURUS;}
        
        //May 25, 2000 7:15 AM Venus enters Gemini
        Date venusBegin195 = sdf.parse("05/24/2000");
        Date venusEnd195 = sdf.parse ("06/18/2000");
        if (uDate.after(venusBegin195) && uDate.before(venusEnd195)) {venus = Sign.GEMINI;}
        
        //June 18, 2000 5:15 PM Venus enters Cancer
        Date venusBegin196 = sdf.parse("06/17/2000");
        Date venusEnd196 = sdf.parse ("07/13/2000");
        if (uDate.after(venusBegin196) && uDate.before(venusEnd196)) {venus = Sign.CANCER;}
        
        //July 13, 2000 3:02 AM Venus enters Leo
        Date venusBegin197 = sdf.parse("07/12/2000");
        Date venusEnd197 = sdf.parse ("08/06/2000");
        if (uDate.after(venusBegin197) && uDate.before(venusEnd197)) {venus = Sign.LEO;}
        
        //Aug 6, 2000 12:32 PM Venus enters Virgo
        Date venusBegin198 = sdf.parse("08/05/2000");
        Date venusEnd198 = sdf.parse ("08/30/2000");
        if (uDate.after(venusBegin198) && uDate.before(venusEnd198)) {venus = Sign.VIRGO;}
        
        //Aug 30, 2000 10:35 PM Venus enters Libra
        Date venusBegin199 = sdf.parse("08/29/2000");
        Date venusEnd199 = sdf.parse ("09/24/2000");
        if (uDate.after(venusBegin199) && uDate.before(venusEnd199)) {venus = Sign.LIBRA;}
        
        //Sep 24, 2000 10:26 AM Venus enters Scorpio
        Date venusBegin200 = sdf.parse("09/23/2000");
        Date venusEnd200 = sdf.parse ("10/19/2000");
        if (uDate.after(venusBegin200) && uDate.before(venusEnd200)) {venus = Sign.SCORPIO;}
        
        //Oct 19, 2000 1:18 AM Venus enters Sagittarius
        Date venusBegin201 = sdf.parse("10/18/2000");
        Date venusEnd201 = sdf.parse ("11/12/2000");
        if (uDate.after(venusBegin201) && uDate.before(venusEnd201)) {venus = Sign.SAGITTARIUS;}
        
        //Nov 12, 2000 9:14 PM Venus enters Capricorn
        Date venusBegin202 = sdf.parse("11/11/2000");
        Date venusEnd202 = sdf.parse ("12/08/2000");
        if (uDate.after(venusBegin202) && uDate.before(venusEnd202)) {venus = Sign.CAPRICORN;}
        
        //Dec 8, 2000 3:48 AM Venus enters Aquarius
        Date venusBegin203 = sdf.parse("12/07/2000");
        Date venusEnd203 = sdf.parse ("01/03/2001");
        if (uDate.after(venusBegin203) && uDate.before(venusEnd203)) {venus = Sign.AQUARIUS;}
        
        //Jan 3, 2001 1:14 PM Venus enters Pisces
        
    }//end setVenus
    
    /*The descendent is 7 signs away from the ascendant (WORKS) */
    private void setDesc () {
        if (getAsc().equalsSign("ARIES")) { descendant = Sign.LIBRA; }
        else if (getAsc().equalsSign("TAURUS")) 		{ descendant = Sign.SCORPIO; }
        else if (getAsc().equalsSign("GEMINI")) 		{ descendant = Sign.SAGITTARIUS; }
        else if (getAsc().equalsSign("CANCER")) 		{ descendant = Sign.CAPRICORN; }
        else if (getAsc().equalsSign("LEO")) 			{ descendant = Sign.AQUARIUS; }
        else if (getAsc().equalsSign("VIRGO"))  		{ descendant = Sign.PISCES; }
        else if (getAsc().equalsSign("LIBRA"))  		{ descendant = Sign.ARIES; }
        else if (getAsc().equalsSign("SCORPIO"))		{ descendant = Sign.TAURUS; }
        else if (getAsc().equalsSign("SAGITTARIUS"))	{ descendant = Sign.GEMINI; }
        else if (getAsc().equalsSign("CAPRICORN"))		{ descendant = Sign.CANCER; }
        else if (getAsc().equalsSign("AQUARIUS"))		{ descendant = Sign.LEO; }
        else  { descendant = Sign. VIRGO; } //(ascendant == Sign.PISCES)
    }//end setDesc
    
    /*Uranus: generational planet (WORKS)
        - list of uranus days/times found at https://cafeastrology.com/urnepplutosigntables.html
        - doesn't take into account the exact time that Uranus changes sign
        - Uranus sign changes at midnight on the specified day
    */
    private void setUranus (String gDate) throws ParseException {
        Date uDate;
        SimpleDateFormat sdf = new SimpleDateFormat ("MM/dd/yyyy");
        uDate = sdf.parse(gDate);
        
        //Nov 16, 1981     7:05 AM  Uranus enters Sagittarius
        Date uranusBegin1 = sdf.parse("11/15/1981");
        Date uranusEnd1 = sdf.parse("12/02/1988");
        if ( uDate.after(uranusBegin1) && uDate.before(uranusEnd1) ) { uranus = Sign.SAGITTARIUS;}

        //Dec  2, 1988    10:35 AM  Uranus enters Capricorn
        Date uranusBegin2 = sdf.parse("12/01/1988");
        Date uranusEnd2 = sdf.parse("04/01/1995");
        if ( uDate.after(uranusBegin2) && uDate.before(uranusEnd2) ) { uranus = Sign.CAPRICORN;}
        
        //Apr  1, 1995     7:11 AM  Uranus enters Aquarius
        Date uranusBegin3 = sdf.parse("03/31/1995");
        Date uranusEnd3 = sdf.parse("06/08/1995");
        if ( uDate.after(uranusBegin3) && uDate.before(uranusEnd3) ) { uranus = Sign.AQUARIUS;}
        
        //Jun  8, 1995    9:42 PM  Uranus Rx enters Capricorn
        Date uranusBegin4 = sdf.parse("06/07/1995");
        Date uranusEnd4 = sdf.parse("01/12/1996");
        if ( uDate.after(uranusBegin4) && uDate.before(uranusEnd4) ) { uranus = Sign.CAPRICORN;}
        
        //Jan 12, 1996     2:13 AM  Uranus enters Aquarius
        Date uranusBegin5 = sdf.parse("01/11/1996");
        Date uranusEnd5 = sdf.parse("03/11/2003");
        if ( uDate.after(uranusBegin5) && uDate.before(uranusEnd5) ) { uranus = Sign.AQUARIUS;}
        
        //Mar 10, 2003     3:53 PM  Uranus enters Pisces  
    } //end setUranus
    
    /* Pluto: generational planets (WORKS)
        - https://cafeastrology.com/urnepplutosigntables.html
        - doesn't take into account the exact time that Uranus changes sign
        - Uranus sign changes at midnight on the specified day */
    private void setPluto (String gDate) throws ParseException {
        Date uDate;
        SimpleDateFormat sdf = new SimpleDateFormat ("MM/dd/yyyy");
        uDate = sdf.parse(gDate);
        
        //Aug 28, 1984    12:44 AM  Pluto enters Scorpio
        Date plutoBegin1 = sdf.parse("08/27/1984");
        Date plutoEnd1 = sdf.parse("01/17/1995");
        if ( uDate.after(plutoBegin1) && uDate.before(plutoEnd1)) { pluto = Sign.SCORPIO; }
        
        //Jan 17, 1995     4:16 AM  Pluto enters Sagittarius
        Date plutoBegin2 = sdf.parse("01/16/1995");
        Date plutoEnd2 = sdf.parse("04/20/1995");
        if (uDate.after(plutoBegin2) && uDate.before(plutoEnd2)) { pluto = Sign.SAGITTARIUS;}
        
        //Apr 20, 1995    10:56 PM  Pluto Rx enters Scorpio
        Date plutoBegin3 = sdf.parse("04/19/1995");
        Date plutoEnd3 = sdf.parse("11/10/1995");
        if (uDate.after(plutoBegin3) && uDate.before(plutoEnd3)) { pluto = Sign.SCORPIO;}
        
        //Nov 10, 1995     2:11 PM  Pluto enters Sagittarius
        Date plutoBegin4 = sdf.parse("11/09/1995");
        Date plutoEnd4 = sdf.parse("01/25/2008");
        if (uDate.after(plutoBegin4) && uDate.before(plutoEnd4)) { pluto = Sign.SAGITTARIUS;}
        
        //Jan 25, 2008     9:37 PM  Pluto enters Capricorn
    }//end setPluto
    
    //getters
    public String getFirstName () { return firstName; }
    public String getLastName () { return lastName; }
    public String getBday () { return birthDay; }
    public String getBirthTime () { return birthTime; }
    public Sign getSun () { return sun; }
    public Sign getMoon () { return moon; }
    public Sign getAsc () { return ascendant; }
    public Sign getMars () { return mars; }
    public Sign getVenus () { return venus; }
    public Sign getDesc () { return descendant; }
    public Sign getUranus () { return uranus; }
    public Sign getPluto () { return pluto; }
    
    //functions
    
    /*isTimeBetweenTwoTime function
        copied from https://stackoverflow.com/questions/17697908/check-if-a-given-time-lies-between-two-times-regardless-of-date*/
    public static boolean isTimeBetweenTwoTime (String initialTime, String finalTime, String currentTime) throws ParseException {
        String reg = "^([0-1][0-9]||2[0-3]):([0-5][0-9])$";
        boolean valid = false;
        if (initialTime.matches(reg) && finalTime.matches(reg) && currentTime.matches(reg)) {
            //valid = false;
            
            //Start Time
            java.util.Date inTime = new SimpleDateFormat("HH:mm").parse(initialTime);
            Calendar calendar1 = Calendar.getInstance();
            calendar1.setTime(inTime);

            //Current Time
            java.util.Date checkTime = new SimpleDateFormat("HH:mm").parse(currentTime);
            Calendar calendar3 = Calendar.getInstance();
            calendar3.setTime(checkTime);

            //End Time
            java.util.Date finTime = new SimpleDateFormat("HH:mm").parse(finalTime);
            Calendar calendar2 = Calendar.getInstance();
            calendar2.setTime(finTime);

            if (finalTime.compareTo(initialTime) < 0) {
                calendar2.add(Calendar.DATE, 1);
                calendar3.add(Calendar.DATE, 1);
            }

            java.util.Date actualTime = calendar3.getTime();
            if ((actualTime.after(calendar1.getTime()) || actualTime.compareTo(calendar1.getTime()) == 0) && actualTime.before(calendar2.getTime())) { 
                valid = true;
                return valid;
            } /* ERROR WITH BELOW CODE: throws the exception even with correct input
            else {
                throw new IllegalArgumentException("Not a valid time, expecting HH:MM:SS format");
            }*/
        }
        return valid;
    }//end isTimeBetweenTwoTime
    
    /*givenTwoDates
        - calculates the number of days between user's bday & 01/01/1900
        - copied from https://www.concretepage.com/java/example_timeunit_java
        - modified to be compatible with Celestial Match */
    public static long givenTwoDates(String userDay) throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date epoch = sdf.parse("01/01/1900");
        Date userBday = sdf.parse(userDay);

        long diffInMillies = Math.abs(userBday.getTime() - epoch.getTime());
        long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

        //assertEquals(diff, 6);

        return diff;
    }
    
}//end of You