package celestialmatch;

import java.util.*;
import java.text.*;
import java.io.IOException;
import java.util.GregorianCalendar;
import celestialmatch.*;

public class CelestialMatch {
    
    //main class
    public static void main(String[] args) throws ParseException, IOException {
        char menuOption;

        GregorianCalendar gc = new GregorianCalendar();
        UserList login = new UserList(); //necessary for credit card implementation
        Scanner input = new Scanner (System.in); //necessary of keyboard input
        
        do {
            
            System.out.println ("Please enter the number of your menu choice:\n1. Input birth data for both individuals\n2. Login or Sign-up\n3. Test with pre-made people\n4. Testing function with random dates and times\n0: Exit program");
            menuOption = input.next().charAt(0);
            
            if (menuOption == '1') { //eventually this will be the only function in the first menu
                
                /* ENTER INFORMATION FOR PERSON A */
                System.out.print ("Enter the first name of Person A: ");
                String fNameA = input.next();
                System.out.print ("Enter the last name of Person A: ");
                String lNameA = input.next();
                System.out.printf ("Please enter the birth month and day for %s (mm/dd/yyyy): ", fNameA);
                String eDate = input.next();
                System.out.print ("Please enter the birth time for Person A (24-hour format, hh:mm):  ");
                String birthTimeA = input.next();
                You userA = new You (fNameA, lNameA, eDate, birthTimeA);

                /* ENTER INFORMATION FOR PERSON B */
                System.out.print ("Enter the first name of Person B: ");
                String fNameB = input.next();
                System.out.print ("Enter the last name of Person B: ");
                String lNameB = input.next();
                System.out.printf ("Please enter the birth month and day for %s (mm/dd/yyyy): ", fNameB);
                eDate = input.next();
                System.out.print ("Please enter the birth time for Person B (24-hour format, hh:mm):  ");
                String birthTime = input.next();
                You userB = new You (fNameB, lNameB, eDate, birthTime);

                //int result;
                //result = (int)Calculate.basicResults (userA, userB);
                
                Calculate result = new Calculate (userA, userB, false);

            }//end menuOption 1
            
            else if (menuOption == '2') {
                login.loadArray("user.txt");
                login.saveArray("user.txt");
                
                boolean signIn = false;
                System.out.println("Enter 1 to signup or Enter 2 to login: ");
                int x = input.nextInt();
                while (x < 1 || x > 2)
                {
                    System.out.println("Invalid input, please re-enter your choice. Enter 1 to signup or Enter 2 to login: ");
                    x = input.nextInt();
                }
                
                if(x == 1)
                {
                    System.out.println("Enter new ID: ");
                    String newID = input.next();       
                    System.out.println("Enter new password: ");
                    String newPassword = input.next();
                
                    login.signUp(newID, newPassword, "user.txt");
                    
                }
               if(x == 2)
               {
                    System.out.println("Enter ID to login: ");
                    String id = input.next();
        
                    System.out.println("Enter password: ");
                    String password = input.next();
                    
                if (login.verify(id, password) == false)
                {
                    System.out.println("login failed");
                    System.out.println("Would you like to sign up for an account?");
                    System.out.println("Please enter 'yes' or 'no': ");
                    String decision = input.next();
            
                    if (decision.equals("yes"))
                    {
                    System.out.println("Enter new ID: ");
                    String newID = input.next();
        
                    System.out.println("Enter new password: ");
                    String newPassword = input.next();
                    
                    login.signUp(newID, newPassword, "user.txt");
                    login.loadArray("user.txt");
                    }
                } else
                   signIn = true;
               }
            }//end menuOption 2

            else if (menuOption == '3') {
                You userA = new You ("Gina", "Alawaye", "08/04/1994", "18:30");
                You userB = new You ("James", "Buchanan", "04/04/1992", "08:25");

                Calculate result = new Calculate (userA, userB, false);
            }//end menuOption 3

            /* TESTING FUNCTION
                generates 100 random birth dates and time and tests them against each other.
                    - the values of relationships that return 0.0, indicate an error in the functionality
                    - means that either the birth day or the birth time was defaulted to null
            */
            else if (menuOption == '4') {
                //vars
                String randoDate1, randoDate2, randoTime1, randoTime2;
                int year1, year2, dayOfYear1, dayOfYear2, time1, time2, time3, time4;

                //formating of testing table
                System.out.printf ("---------------------------------------------TESTING---------------------------------------------\n"+
                                "%s\t%s\t\t%s\t%s\t\t%s\t%s\t%s\t%s\n", "#", "DateA", "TimeA", "DateB", "TimeB", "RelationSum1" , "RelationSum2", "Total Compatibility");

                //for loop to generate 100 days and times
                for (int i = 0; i < 50; i++) {
                    //set values for personA
                    year1 = randBetween (1985, 2000);
                    gc.set (gc.YEAR, year1);
                    dayOfYear1 = randBetween (1, gc.getActualMaximum (gc.DAY_OF_YEAR));
                    gc.set (gc.DAY_OF_YEAR, dayOfYear1);
                    randoDate1 = (gc.get (gc.MONTH) + 1) + "/" + gc.get(gc.DAY_OF_MONTH) + "/" + gc.get(gc.YEAR);
                    time1 = randBetween (0, 24); time2 = randBetween (0, 59);
                    randoTime1 = time1 + ":" + time2;

                    //set values for personB
                    year2 = randBetween (1985, 2000);
                    gc.set (gc.YEAR, year2);
                    dayOfYear2 = randBetween (1, gc.getActualMaximum (gc.DAY_OF_YEAR));
                    gc.set (gc.DAY_OF_YEAR, dayOfYear2);
                    randoDate2 = (gc.get (gc.MONTH) + 1) + "/" + gc.get(gc.DAY_OF_MONTH) + "/" + gc.get(gc.YEAR);
                    time3 = randBetween (0, 24); time4 = randBetween (0, 59);
                    randoTime2 = time3 + ":" + time4;

                    //create new You objects with random values
                    You testA = new You (String.valueOf (i+1), "", randoDate1, randoTime1);
                    You testB = new You (String.valueOf (i+1), "", randoDate2, randoTime2);

                    Calculate result = new Calculate (testA, testB, false);
                }
            }//end menuOption 4
            
            else if (menuOption == '0') 
                { System.out.println ("Goodbye!"); }
            
            else
                { System.err.println ("ERROR! Invalid input. Try again: "); }
            
        } while (menuOption != '0');

    }//end main method

    public static int randBetween (int start, int end)
        { return start + (int)Math.round (Math.random() * (end - start)); }

    @Override
    public String toString () {
        String date = "Hi! This is just in case I need to format strings";
        return date;
    }
    
}//end class CelestialMatch
