/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celestialmatch;

import java.io.*;
import java.util.*;
/**
 *
 * @author Jie
 */
public class UserList {
    List<User> userList = new ArrayList<>();
    CreditCard card = new CreditCard();
    Scanner input = new Scanner (System.in);

//load array from file
    public void loadArray(String filename) throws IOException{
        
        String userName;
        String password;
        
            
       File file = new File(filename);
        try{
            Scanner scanner = new Scanner(file);
            while(scanner.hasNextLine()){               
                userName = scanner.next();                
                password = scanner.next();              
                User temp = new User(userName,password);
                userList.add(temp);                            
            }
        }
        catch(IOException e)
                {
                    System.out.println(e.toString());
                    System.out.println("Fail");
                }
    }
    public void saveArray(String filename) throws IOException{
       try(FileWriter filewriter = new FileWriter(filename)) {  
            PrintWriter printwriter = new PrintWriter(filewriter);
            
            User[] userArray = userList.toArray(new User[userList.size()]);
            for(int i = 0; i < userList.size(); i++)//using for loop to save array
            {
                printwriter.print(userArray[i].getUserName());
                printwriter.print(" ");
                printwriter.print(userArray[i].getPassword());
                if (i != userList.size()-1)//if statement to prvent printing extra line
                    printwriter.println();
            }
    }
       catch(IOException e){
        System.out.println("Fail");
        }
    }
    
//add new user to file
    public boolean signUp(String newUserID, String newPassword, long creditNum, int securityCode, int xpDate, String ffName, String llName, String filename) throws IOException{
        
        Boolean payment = false;
        while(verify(newUserID, newPassword))
      {
          System.out.println("User ID already exist, Please try again!");
          System.out.println("Enter new ID:");
          newUserID = input.next();
          
          System.out.println("Enter new password:");
          newPassword = input.next();
      }
    try(FileWriter filewriter = new FileWriter(filename)) {  
            PrintWriter printwriter = new PrintWriter(filewriter);
            
            User[] userArray = userList.toArray(new User[userList.size()]);
            for(int i = 0; i < userList.size(); i++)//using for loop to save array
            {
                printwriter.print(userArray[i].getUserName());
                printwriter.print(" ");
                printwriter.print(userArray[i].getPassword());
                printwriter.println();
            }
            printwriter.print(newUserID);//adding new user to file
            printwriter.print(" ");
            printwriter.print(newPassword);
            
            
          
            long CN = creditNum;
         while(payment = false)
         {
            if(card.isValid(CN))
            {
                System.out.println("Card is valid");
                payment = true;
            }
            else
            {
                System.out.println("Card is not valid");
            }
         }
 
         int secCode = securityCode;
         
         int expirationDate = xpDate;
         
         String fName = ffName;
         
         String lName = llName;
         
         card.signUpCC(CN, secCode, expirationDate, fName, lName);
         loadArray(filename);
    }
       catch(IOException e){
        System.out.println("Fail");
        }
        //System.out.println("SignUp successful!");
        return true;
    }
    
    //verify login process
       public boolean verify(String userName, String password){
         
           boolean match = false;
           User[] userArray = userList.toArray(new User[userList.size()]);
           for (int i = 0; i < userList.size(); i++){
               if(userArray[i].getUserName().equals(userName)&&userArray[i].getPassword().equals(password))
               {
                   match = true;//if user name and password match, match = true;
                    
               }     
       }
        return match;//returning the boolean
    }
}
