//This class does the calculations of the relationship
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celestialmatch;

import celestialmatch.Signs.Sign;
import celestialmatch.You.*;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.util.*;
import java.text.*;
import java.io.IOException;
import celestialmatch.*;
import celestialmatch.Calculate;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Calculate {
    //global variables
    double percentComp;
    int deep, pass, phys, pers, intel, harm, sens, open, sex, comp, marry, emo, inst;
    
    //constructors
    Calculate (You a, You b, boolean premium) { 
        if (premium == false) { basicResults (a, b); }
        else { advancedResults (a, b); }
    }
    
    /*
    _________________________________________________________________________________
    |________|ARIES|TAURUS|GEMINI|CANCER|LEO|VIRGO|LIBRA|SCORPIO|SAG|CAP|AQUA|PISCES|
    |ARIES   |  3  |  2   |   4  |  1   | 5 |  2  |  3  |   2   | 5 | 1 | 4  |  2   |
    |TAURUS  |  2  |  3   |   2  |  4   | 1 |  5  |  2  |   3   | 2 | 5 | 1  |  4   |
    |GEMINI  |  4  |  2   |   3  |  2   |
    |CANCER  |  1  |  4   |   2  |  3   |
    |LEO     |  5  |  1   |   4  |  2   |
    |VIRGO   |  2  |  5   |   1  |  4   |
    |LIBRA   |  3  |  2   |   5  |  1   |
    |SCORPIO |  2  |  3   |   2  |  5   |
    |SAG     |  5  |  2   |   3  |  2   |
    |CAP     |  1  |  5   |   2  |  3   |
    |AQUA    |  4  |  1   |   5  |  2   |
    |PISCES  |  2  |  4   |   1  |  5   |
    
*/
    
    private static final int [][] TABLE =  new int [][] {
        /*Aries (0)*/ { 3, 2, 4, 1, 5, 2, 3, 2, 5, 1, 4, 2 },
       /*Taurus (1)*/ { 2, 3, 2, 4, 1, 5, 2, 3, 2, 5, 1, 4 },
       /*Gemini (2)*/ { 4, 2, 3, 2, 4, 1, 5, 2, 3, 2, 5, 1 },
       /*Cancer (3)*/ { 1, 4, 2, 3, 2, 4, 1, 5, 2, 3, 2, 5 },
          /*Leo (4)*/ { 5, 1, 4, 2, 3, 2, 4, 1, 5, 2, 3, 2 },
        /*Virgo (5)*/ { 2, 5, 1, 4, 2, 3, 2, 4, 1, 5, 2, 3 },
        /*Libra (6)*/ { 3, 2, 5, 1, 4, 2, 3, 2, 4, 1, 5, 2 },
      /*Scorpio (7)*/ { 2, 3, 2, 5, 1, 4, 2, 3, 2, 4, 1, 5 },
  /*Sagittarius (8)*/ { 5, 2, 3, 2, 5, 1, 4, 2, 3, 2, 4, 1 },
    /*Capricorn (9)*/ { 1, 5, 2, 3, 2, 5, 1, 4, 2, 3, 2, 4 },
    /*Aquarius (10)*/ { 4, 1, 5, 2, 3, 2, 5, 1, 4, 2, 3, 2 },
      /*Pisces (11)*/ { 2, 4, 1, 5, 2, 3, 2, 5, 1, 4, 2, 3 }
    };
    
    private double avg (double a, double b) { return a/2; }
    
    private double signComp (Sign a, Sign b) {
        double avgSignComp;
        int spotA = 0;
        
        if (a == Sign.ARIES) {
            if (b == Sign.ARIES)       { spotA = TABLE [0][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [0][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [0][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [0][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [0][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [0][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [0][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [0][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [0][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [0][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [0][10];}            if (b == Sign.PISCES)      { spotA = TABLE [0][11];}
        }
        
        if (a == Sign.TAURUS) {
            if (b == Sign.ARIES)       { spotA = TABLE [1][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [1][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [1][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [1][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [1][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [1][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [1][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [1][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [1][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [1][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [1][10];}            if (b == Sign.PISCES)      { spotA = TABLE [1][11];}
        }
        
        if (a == Sign.GEMINI) {
            if (b == Sign.ARIES)       { spotA = TABLE [2][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [2][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [2][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [2][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [2][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [2][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [2][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [2][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [2][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [2][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [2][10];}            if (b == Sign.PISCES)      { spotA = TABLE [2][11];}
        }

        if (a == Sign.CANCER) {
            if (b == Sign.ARIES)       { spotA = TABLE [3][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [3][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [3][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [3][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [3][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [3][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [3][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [3][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [3][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [3][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [3][10];}            if (b == Sign.PISCES)      { spotA = TABLE [3][11];}
        }
        
        if (a == Sign.LEO) {
            if (b == Sign.ARIES)       { spotA = TABLE [4][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [4][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [4][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [4][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [4][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [4][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [4][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [4][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [4][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [4][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [4][10];}            if (b == Sign.PISCES)      { spotA = TABLE [4][11];}
        }
        
        if (a == Sign.VIRGO) {
            if (b == Sign.ARIES)       { spotA = TABLE [5][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [5][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [5][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [5][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [5][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [5][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [5][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [5][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [5][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [5][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [5][10];}            if (b == Sign.PISCES)      { spotA = TABLE [5][11];}
        }
        
        if (a == Sign.LIBRA) {
            if (b == Sign.ARIES)       { spotA = TABLE [6][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [6][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [6][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [6][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [6][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [6][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [6][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [6][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [6][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [6][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [6][10];}            if (b == Sign.PISCES)      { spotA = TABLE [6][11];}
        }
        
        if (a == Sign.SCORPIO) {
            if (b == Sign.ARIES)       { spotA = TABLE [7][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [7][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [7][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [7][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [7][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [7][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [7][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [7][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [7][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [7][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [7][10];}            if (b == Sign.PISCES)      { spotA = TABLE [7][11];}
        }
        
        if (a == Sign.SAGITTARIUS) {
            if (b == Sign.ARIES)       { spotA = TABLE [8][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [8][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [8][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [8][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [8][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [8][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [8][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [8][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [8][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [8][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [8][10];}            if (b == Sign.PISCES)      { spotA = TABLE [8][11];}
        }
        
        if (a == Sign.CAPRICORN) {
            if (b == Sign.ARIES)       { spotA = TABLE [9][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [9][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [9][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [9][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [9][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [9][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [9][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [9][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [9][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [9][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [9][10];}            if (b == Sign.PISCES)      { spotA = TABLE [9][11];}
        }
        
        if (a == Sign.AQUARIUS) {
            if (b == Sign.ARIES)       { spotA = TABLE [10][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [10][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [10][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [10][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [10][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [10][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [10][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [10][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [10][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [10][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [10][10];}            if (b == Sign.PISCES)      { spotA = TABLE [10][11];}
        }
        
        if (a == Sign.PISCES) {
            if (b == Sign.ARIES)       { spotA = TABLE [11][0]; }            if (b == Sign.TAURUS)      { spotA = TABLE [11][1]; }
            if (b == Sign.GEMINI)      { spotA = TABLE [11][2]; }            if (b == Sign.CANCER)      { spotA = TABLE [1][3]; }
            if (b == Sign.LEO)         { spotA = TABLE [11][4]; }            if (b == Sign.VIRGO)       { spotA = TABLE [11][5]; }
            if (b == Sign.LIBRA)       { spotA = TABLE [11][6]; }            if (b == Sign.SCORPIO)     { spotA = TABLE [11][7]; }
            if (b == Sign.SAGITTARIUS) { spotA = TABLE [11][8]; }            if (b == Sign.CAPRICORN)   { spotA = TABLE [11][9]; }
            if (b == Sign.AQUARIUS)    { spotA = TABLE [11][10];}            if (b == Sign.PISCES)      { spotA = TABLE [11][11];}
        }
        
        //avgSignComp = (double)return spotA;

//BELOW IS COMMENTED OUT FOR DEBUGGING PURPOSES; uncomment when debugging is complete        
/*        if (spotA == 0.0) {
            System.err.println ("Error calculating individual sign compatibility. Terminating.");
            System.exit (1);
            return -1;
        } else
            { return spotA; }*/

        return spotA;
    }
    
    private double compCalculate (You a, You b) {
        
        Sign sunA = a.getSun();             Sign sunB = b.getSun();
        Sign ascA = a.getAsc();             Sign ascB = b.getAsc();
        Sign descA = a.getDesc();           Sign descB = b.getDesc();
        Sign moonA = a.getMoon();           Sign moonB = b.getMoon();
        Sign marsA = a.getMars();           Sign marsB = b.getMars();
        Sign venusA = a.getVenus();         Sign venusB = b.getVenus();
        Sign uranusA = a.getUranus();       Sign uranusB = b.getUranus();
        Sign plutoA = a.getPluto();         Sign plutoB = b.getPluto();
        
        double relationSum1 = 0.0, relationSum2 = 0.0 , relationalAvg;

        relationSum1 = signComp (sunA, moonB) + signComp (sunA, venusB) +  signComp (venusA, venusB) + signComp (moonA, ascB) + signComp (moonA, moonB) + signComp (marsA, moonB)
                + signComp (venusA, ascB) + signComp (marsA, marsB) + signComp (marsA, moonB) + signComp (descA, moonB) + signComp (sunA, sunB) + signComp (plutoA, venusB) + signComp (uranusA, venusB);
        
        relationSum2 = signComp (sunB, moonA) + signComp (sunB, venusA) +  signComp (venusB, venusA) + signComp (moonB, ascA) + signComp (moonB, moonA) + signComp (marsB, moonA)
                + signComp (venusB, ascA) + signComp (marsB, marsA) + signComp (marsB, moonA) + signComp (descB, moonA) + signComp (sunB, sunA) + signComp (plutoB, venusA) + signComp (uranusB, venusA);
        
        relationalAvg = (relationSum1 + relationSum2); //90)*100;
        
        //THE FOLLOWING INCLUDED FOR TEST PURPOSES
        System.out.printf ("%s\t%s\t%s\t%s\t%s\t%.2f\t\t%.2f\t\t%.2f\n", a.getFirstName(), a.getBday(), a.getBirthTime(), b.getBday(), b.getBirthTime(), relationSum1, relationSum2, relationalAvg);
        if (signComp (sunA, moonB) == 0 || signComp (sunB, moonA) == 0)
            { System.err.printf ("\t\tError in computation for sun-moon calculation\n\t\t\tSunA = %s \tSunB = %s\tMoonA = %s\tMoonB = %s\n", sunA, sunB, moonA, moonB); }
        
        if (signComp (sunA, venusB) == 0 || signComp (sunB, venusA) == 0)
            { System.err.printf ("\t\tError in computation for sun-venus calculation\n\t\t\tSunA = %s \tSunB = %s\tVenusA = %s\tVenusB = %s\n", sunA, sunB, venusA, venusB); }
        
        if (signComp (venusA, venusB) == 0 || signComp (venusB, venusA) == 0)
            { System.err.printf ("\t\tError in computation for venus-venus calculation\n\t\t\tVenusA = %s\tVenusB = %s\n", venusA, venusB); }
        
        if (signComp (moonA, ascB) == 0 || signComp (moonB, ascA) == 0)
            { System.err.printf ("\t\tError in computation for moon-asc calculation\n\t\t\tMoonA = %s \tMoonB = %s\tAscA = %s\tAscB = %s\n", moonA, moonB, ascA, ascB); }
        
        if (signComp (moonA, moonB) == 0 || signComp (moonB, moonA) == 0)
            { System.err.printf ("\t\tError in computation for moon-moon calculation\n\t\t\tMoonA = %s\tMoonB = %s\n", moonA, moonB); }
        
        if (signComp (marsA, moonB) == 0 || signComp (marsB, moonA) == 0)
            { System.err.printf ("\t\tError in computation for mars-moon calculation\n\t\t\tMarsA = %s \tMarsB = %s\tMoonA = %s\tMoonB = %s\n", marsA, marsB, moonA, moonB); }
        
        if (signComp (venusA, ascB) == 0 || signComp (venusB, ascA) == 0)
            { System.err.printf ("\t\tError in computation for venus-asc calculation\n\t\t\tVenusA = %s \tVenusB = %s\tAscA = %s\tAscB = %s\n", venusA, venusB, ascA, ascB); }
        
        if (signComp (marsA, marsB) == 0 || signComp (marsB, marsA) == 0)
            { System.err.printf ("\t\tError in computation for mars-mars calculation\n\t\t\tMarsA = %s\tMarsB = %s\n", marsA, marsB); }
        
        if (signComp (marsA, moonB) == 0 || signComp (marsB, moonA) == 0)
            { System.err.printf ("\t\tError in computation for mars-moon calculation\n\t\t\tMarsA = %s \tMarsB = %s\tMoonA = %s\tMoonB = %s\n", marsA, marsB, moonA, moonB); }
        
        if (signComp (descA, moonB) == 0 || signComp (descB, moonA) == 0)
            { System.err.printf ("\t\tError in computation for desc-moon calculation\n\t\t\tDescA = %s \tDescB = %s\tMoonA = %s\tMoonB = %s\n", descA, descB, moonA, moonB); }
        
        if (signComp (sunA, sunB) == 0 || signComp (sunB, sunA) == 0)
            { System.err.printf ("\t\tError in computation for sun-sun calculation\n\t\t\tSunA = %s\tSunB = %s\n", sunA, sunB); }
        
        if (signComp (plutoA, venusB) == 0 || signComp (plutoB, venusA) == 0)
            { System.err.printf ("\t\tError in computation for pluto-venus calculation\n\t\t\tPlutoA = %s \tPlutoB = %s\tVenusA = %s\tVenusB = %s\n", plutoA, plutoB, venusA, venusB); }
        
        if (signComp (uranusA, venusB) == 0 || signComp (uranusB, venusA) == 0)
            { System.err.printf ("\t\tError in computation for uranus-venus calculation\n\t\t\tUranusA = %s \tUranusB = %s\tVenusA = %s\tVenusB = %s\n", uranusA, uranusB, venusA, venusB); }        
        
        System.out.printf ("---------------------------------------------------------------------------------------------------\n");
        
        //Error Handling
        if (relationalAvg == 0.0) {
            //System.err.println ("Error calculating relational sums. Terminating");
            //System.exit(-1);
            //return (-1);
            System.err.println ("Date/Birth time entered resulted in a null value");
            System.err.printf ("BirthDayA: %s BirthTimeA: %s | BirthDayB: %s BirthTimeB: %s\n", a.getBday(), a.getBirthTime(), b.getBday(), b.getBirthTime());
            return relationalAvg; 
        } else
            { return relationalAvg; }
    }
    
    /* Displays the compatibility results for the basic user */
    public double basicResults (You a, You b) {
        Sign sunA = a.getSun();             Sign sunB = b.getSun();
        Sign ascA = a.getAsc();             Sign ascB = b.getAsc();
        Sign descA = a.getDesc();           Sign descB = b.getDesc();
        Sign moonA = a.getMoon();           Sign moonB = b.getMoon();
        Sign marsA = a.getMars();           Sign marsB = b.getMars();
        Sign venusA = a.getVenus();         Sign venusB = b.getVenus();
        Sign uranusA = a.getUranus();       Sign uranusB = b.getUranus();
        Sign plutoA = a.getPluto();         Sign plutoB = b.getPluto();
        
//BELOW HAS BEEN COMMENTED OUT FOR TESTING PURPOSES
        /* DISPLAY RESULTS */
//        String name = "Name", sun = "Sun", moon = "Moon", asc = "Ascendant", desc = "Descendant", mars = "Mars", venus = "Venus", uranus = "Uranus", pluto = "Pluto";
//        System.out.printf("--------------CHART ASPECTS FOR BOTH PARTIES-------------\n%s\t%5s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\n", name, sun, asc, desc, moon, mars, venus, uranus, pluto);
//        System.out.printf ("%s\t%5s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\n", a.getFirstName(), sunA, ascA, descA, moonA, marsA, venusA, uranusA, plutoA);
//        System.out.printf ("%s\t%5s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\n", b.getFirstName(), sunB, ascB, descB, moonB, marsB, venusB, uranusB, plutoB);
//
//        percentComp = compCalculate (a, b);
//
//        System.out.printf ("%s and %s are %.2f%% compatible. Congrats\n\n", a.getFirstName(), b.getFirstName(), percentComp);
        
        percentComp = compCalculate (a, b);
        
        deep = (int)((signComp (sunA, moonB) + signComp (sunB, moonA))/2)* 20;
        pass = (int)((signComp (venusA, marsB) + signComp (venusB, marsA))/2)* 20;
        phys = (int)((signComp (moonA, ascB) + signComp (moonB, ascA))/2)* 20;
        pers = (int)((signComp (sunA, sunB) + signComp (sunB, sunA))/2)* 20;
        intel = (int)((signComp (uranusA, venusB) + signComp (uranusB, venusA))/2)* 20;
        harm = (int)((signComp (venusA, ascB) + signComp (venusB, ascA))/2)* 20;
        sens = (int)((signComp (venusA, venusB) + signComp (venusB, venusA))/2)* 20;
        open = (int)((signComp (sunA, venusB) + signComp (sunB, venusA))/2)* 20;
        sex = (int)((signComp (marsA, marsB) + signComp (marsB, marsA))/2)* 20;
        comp = (int)((signComp (marsA, moonB) + signComp (marsB, moonA))/2)* 20;
        marry = (int)((signComp (descA, moonB) + signComp (descB, moonA))/2)* 20;
        emo = (int)((signComp (moonA, moonB) + signComp (moonB, moonA))/2)* 20;
        inst = (int)((signComp (plutoA, venusB) + signComp (plutoB, venusA))/2)* 20;
        
        int i = (int)percentComp;
        //barOverallComp.setValue(i);
        
        return percentComp; 
    }

    /* Displays the compatibility results for the premium user */
    public void advancedResults (You a, You b) {
        Sign sunA = a.getSun();             Sign sunB = b.getSun();
        Sign ascA = a.getAsc();             Sign ascB = b.getAsc();
        Sign descA = a.getDesc();           Sign descB = b.getDesc();
        Sign moonA = a.getMoon();           Sign moonB = b.getMoon();
        Sign marsA = a.getMars();           Sign marsB = b.getMars();
        Sign venusA = a.getVenus();         Sign venusB = b.getVenus();
        Sign uranusA = a.getUranus();       Sign uranusB = b.getUranus();
        Sign plutoA = a.getPluto();         Sign plutoB = b.getPluto();

//        String name = "Name", sun = "Sun", moon = "Moon", asc = "Ascendant", desc = "Descendant", mars = "Mars", venus = "Venus", uranus = "Uranus", pluto = "Pluto";
//        System.out.printf("--------------CHART ASPECTS FOR BOTH PARTIES-------------\n%s\t%5s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\n", name, sun, asc, desc, moon, mars, venus, uranus, pluto);
//        System.out.printf ("%s\t%5s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\n", a.getFirstName(), sunA, ascA, descA, moonA, marsA, venusA, uranusA, plutoA);
//        System.out.printf ("%s\t%5s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\t%15s\n", b.getFirstName(), sunB, ascB, descB, moonB, marsB, venusB, uranusB, plutoB);

        percentComp = compCalculate (a, b);

        //System.out.printf ("%s and %s are %.2f%% compatible. Congrats\n\n", a.getFirstName(), b.getFirstName(), percentComp);

        //displays individual scores that will make the composite
        //display avg score for sunMoons
        double sunMoonAvg = (signComp (sunA, moonB) + signComp (sunB, moonA)) * 10;
        deep = (int)sunMoonAvg;
        
        //sunVenus
        double sunVenusAvg = (signComp (sunA, venusB) + signComp (sunB, venusA) ) * 10;
        open = (int)sunVenusAvg;
        
        //venusMars
        double venusMarsAvg = (signComp (venusA, marsB) + signComp (venusB, marsA)) * 10;
        pass = (int)venusMarsAvg;
        
        //moonsAsc
        double moonAscAvg = (signComp (moonA, ascB) + signComp (moonB, ascA) ) * 10;
        phys = (int)moonAscAvg;
        
        //moonMoon
        double moonMoonAvg = (signComp (moonA, moonB) + signComp (moonB, moonA) ) * 10;
        emo = (int)moonMoonAvg;
       
        //venusVenus
        double venusVenusAvg = (signComp (venusA, venusB) + signComp (venusB, venusA) ) * 10;
        sens = (int)venusVenusAvg;
        
        //venusAsc
        double venusAscAvg = (signComp (venusA, ascB) + signComp (venusB, ascA) ) * 10;
        harm = (int)venusAscAvg;
        
        //marsMars
        double marsMarsAvg = (signComp (marsA, marsB) + signComp (marsB, marsA) ) * 10;
        sex = (int)marsMarsAvg;
        
        //marsMoon
        double marsMoonAvg = (signComp (marsA, moonB) + signComp (marsB, moonA) ) * 10;
        comp = (int)marsMoonAvg;
        
        //descMoon
        double descMoonAvg = (signComp (descA, moonB) + signComp (descB, moonA)) * 10;
        marry = (int)descMoonAvg;
        
        //sunSun
        double sunSunAvg = (signComp (sunA, sunB) + signComp (sunB, sunA) ) * 10;
        pers = (int)sunSunAvg;
        
        //plutoVenus
        double plutoVenusAvg = (signComp (plutoA, venusB) + signComp (plutoB, venusA) ) * 10;
        inst = (int)plutoVenusAvg;
        
        //uranusVenus
        double uranusVenusAvg = (signComp (uranusA, venusB) + signComp (uranusB, venusA) ) * 10;
        intel = (int)uranusVenusAvg;
    }//end advancedResults
    
    
}//end Calculate
