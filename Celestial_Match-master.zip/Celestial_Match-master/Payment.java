/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celestialmatch;

/**
 *
 * @author Jie
 */
public class Payment {
    private long cardNumber;
    private int securityCode;
    private int expirationDate;
    private String fName;
    private String lName;
    private String billingAddress;
    
//Constructor 
    public Payment(long cardNumber, int securityCode, int expirationDate, String fName, String lName) {
        this.cardNumber = cardNumber;
        this.securityCode = securityCode;
        this.expirationDate = expirationDate;
        this.fName = fName;
        this.lName = lName;

    }
//Getter 

    public long getCardNumber() {
        return cardNumber;
    }

    public int getSecurityCode() {
        return securityCode;
    }

    public int getExpirationDate() {
        return expirationDate;
    }

    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

}
