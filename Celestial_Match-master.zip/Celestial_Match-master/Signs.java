package celestialmatch;

public class Signs {
    enum Sign {
           //enum var for aries         //enum var for taurus
           ARIES ("ARIES"),             TAURUS ("TAURUS"),
           
           //enum var for gemini        //enum var for cancer
           GEMINI ("GEMINI"),           CANCER ("CANCER"),
           
           //enum var for leo           //enum var for virgo
           LEO ("LEO"),                 VIRGO ("VIRGO"),
           
           //enum var for libra         //enum var for scorpio
           LIBRA ("LIBRA"),             SCORPIO ("SCORPIO"),
           
           //enum var for sagittarius   //enum var for capricorn
           SAGITTARIUS ("SAGITTARIUS"), CAPRICORN ("CAPRICORN"),
           
           //enum var for aquarius      //enum var for pisces
           AQUARIUS ("AQUARIUS"),       PISCES ("PISCES");
           
          private final String sign;
          
          private Sign (String s)
            { sign = s; }
          
          public boolean equalsSign (String otherSign)
              { return sign.equals(otherSign); }
          
          @Override
          public String toString ()
            { return this.sign; }
    }
}