# Celestial_Match
Software Engineering Project (Spring 2018)

Celestial Match is a project developed for Software Engineering (Spring 2018) at TAMUCC.

The software is a compatibility algorithm, where the user enters the birth days and times for two individuals
 and the system outputs a compatibility score for the two individuals. Compatibility is based on astrological compatibility.
 The end goal is to have a simply GUI for the users to input information, the algorithm, and the means for users to become
 premium users by entering their credit card information.
 
Collaborators:
  - Gina Alawaye
  - Rebekah Boudreau
  - Jie Kong
