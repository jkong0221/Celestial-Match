/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celestialmatch;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Jie
 */
public class CreditCard {
    List<Payment> cardList = new ArrayList<>();
/**
 * Return true if the credit card number is valid
 * @param number
 * @return 
 */    
    public static boolean isValid(long number)
    {
        int sumEvenPlaces = 0;
        int sumOddPlaces = 0;
        boolean result = false;
        
        if(getSize(number) >= 13 || getSize(number) <= 16)
            if(prefixMatched(number,4)||prefixMatched(number,5)||prefixMatched(number,6)||prefixMatched(number,37))
            {
                sumEvenPlaces = sumOfDoubleEvenPlace(number);
                sumOddPlaces = sumOfOddPlace(number);
                result = ((sumEvenPlaces + sumOddPlaces)% 10 == 0);
            }
        return result;
    }
    
    public static int sumOfOddPlace(long number)
    {
        int sumOddPlaces = 0;
        String numberToString = Long.toString(number);
        
        for(int i = 1; i < numberToString.length(); i += 2)
            sumOddPlaces += getDigit(Character.getNumericValue(numberToString.charAt(i)));
        
        return sumOddPlaces;
    }
/**
 * Get the result from Step 2
 * @param number
 * @return 
 */
    public static int sumOfDoubleEvenPlace(long number)
    {
        int sumEvenPlaces = 0;
        String numberToString = Long.toString(number);
        
        for(int i = 0; i < numberToString.length(); i += 2)
            sumEvenPlaces += (getDigit(Character.getNumericValue(numberToString.charAt(i))*2));
        
        return sumEvenPlaces;
    }
/**
 * Return this number if it is a single digit, otherwise,
 * return the sum of the two digits
 * @param number
 * @return 
 */   
    public static int getDigit(int number)
    {
        if(Integer.toString(number).length() == 1)
            return number;
        else 
            return ((number % 10) + 1);
    }
/**
 * Return true if the digit d is a prefix for number
 * @param number
 * @param d
 * @return 
 */
    public static boolean prefixMatched(long number, int d)
    {
        int length = new StringBuilder(Integer.toString(d)).length();
        String numberToString = Long.toString(number);
        String dToString = Integer.toString(d);
        
        for(int i = 0; i < length; i++)
            if(numberToString.charAt(i) != dToString.charAt(i))
                return false;
            
        return true;
    }
/**
 * Return the number of digits in d 
 * @param d
 * @return 
 */
    public static int getSize(long d)
    { 
    return Long.toString(d).length();
    }
    
    public void saveArray(String filename) throws IOException{
       try(FileWriter filewriter = new FileWriter(filename)) {  
            PrintWriter printwriter = new PrintWriter(filewriter);
            
           Payment[] cardArray = cardList.toArray(new Payment[cardList.size()]);
            for(int i = 0; i < cardList.size(); i++)//using for loop to save array
            {
                printwriter.print(cardArray[i].getCardNumber());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getSecurityCode());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getExpirationDate());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getfName());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getlName());
               
                if (i != cardList.size()-1)//if statement to prvent printing extra line
                    printwriter.println();
            }
    }
       catch(IOException e){
        System.out.println("Fail");
        }
    }
    public void loadArray(String filename) throws IOException{
        
        long cardNumber;
        int securityCode;
        int expirationDate;
        String fName;
        String lName;
 
                
        
            
       File file = new File(filename);
        try{
            Scanner scanner = new Scanner(file);
            while(scanner.hasNextLine()){               
                cardNumber = scanner.nextLong();                
                securityCode = scanner.nextInt(); 
                expirationDate = scanner.nextInt();
                fName = scanner.next();
                lName = scanner.next();         
                Payment temp = new Payment(cardNumber, securityCode, expirationDate, fName, lName);
                cardList.add(temp);                            
            }
        }
        catch(IOException e)
                {
                    System.out.println(e.toString());
                    System.out.println("Fail");
                }
    }
    public void signUpCC(long newCN, int newSecCode, int newExDate, String newfName, String newlName) throws IOException{
        loadArray("creditCard.txt");
        {
            try(FileWriter filewriter = new FileWriter("creditCard.txt")) {  
            PrintWriter printwriter = new PrintWriter(filewriter);
            
            Payment[] cardArray = cardList.toArray(new Payment[cardList.size()]);
            for(int i = 0; i < cardList.size(); i++)//using for loop to save array
            {
                printwriter.print(cardArray[i].getCardNumber());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getSecurityCode());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getExpirationDate());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getfName());
                printwriter.print(" ");
                printwriter.print(cardArray[i].getlName());
                printwriter.println();
            }
            printwriter.print(newCN);//adding new user to file
            printwriter.print(" ");
            printwriter.print(newSecCode);//adding new user to file
            printwriter.print(" ");
            printwriter.print(newExDate);//adding new user to file
            printwriter.print(" ");
            printwriter.print(newfName);//adding new user to file
            printwriter.print(" ");
            printwriter.print(newlName);//adding new user to file
        }
        }
    }
}


